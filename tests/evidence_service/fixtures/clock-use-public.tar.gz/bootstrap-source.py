"""Collect guest clock discipline and strongSwan clock-use evidence in isolated VMs."""

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shlex
import subprocess
import time


IMAGE_URL = "https://cloud-images.ubuntu.com/noble/current/noble-server-cloudimg-amd64.img"
IMAGE_SHA256 = "04e8f2461a16a44e78a370284471f29616cdd9baf1893df25807b71f985b6c94"
GUESTS = [
    {"id": "TC_I_A", "zone": "red", "layer": "inner", "index": 0, "side": "a"},
    {"id": "TC_I_B", "zone": "red", "layer": "inner", "index": 1, "side": "b"},
    {"id": "TC_O_A", "zone": "gray", "layer": "outer", "index": 2, "side": "a"},
    {"id": "TC_O_B", "zone": "gray", "layer": "outer", "index": 3, "side": "b"},
]


def utc():
    return datetime.now(timezone.utc).isoformat()


def digest(path):
    result = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1048576), b""):
            result.update(chunk)
    return result.hexdigest()


class Lab:
    def __init__(self, root, phase):
        self.root = Path(root).resolve()
        self.private = self.root / "private"
        self.images = self.root / "images"
        self.output = self.root / "captures" / phase
        self.output.mkdir(parents=True, exist_ok=False)
        self.private.mkdir(mode=0o700, parents=True, exist_ok=True)
        self.images.mkdir(parents=True, exist_ok=True)
        self.records = []
        self.phase = phase

    def run(self, command, required=True, timeout=60):
        started = utc()
        try:
            result = subprocess.run(list(map(str, command)), capture_output=True,
                                    text=True, timeout=timeout)
            row = {"command": list(map(str, command)), "startedAt": started,
                   "endedAt": utc(), "returncode": result.returncode,
                   "stdout": result.stdout, "stderr": result.stderr}
        except subprocess.TimeoutExpired as error:
            row = {"command": list(map(str, command)), "startedAt": started,
                   "endedAt": utc(), "returncode": 124,
                   "stdout": (error.stdout or b"").decode() if isinstance(error.stdout, bytes)
                   else error.stdout or "", "stderr": "Command timed out"}
        row["id"] = f"{self.phase}:{len(self.records):04d}"
        self.records.append(row)
        with (self.output / "observations.jsonl").open("a") as stream:
            stream.write(json.dumps(row) + "\n")
        if required and row["returncode"]:
            raise RuntimeError(f"{row['id']}: command failed: {row['stderr'][-1500:]}")
        return row

    def ssh_command(self, guest, command):
        return ["ssh", "-i", self.private / "access", "-p", 22610 + guest["index"],
                "-o", "BatchMode=yes", "-o", "ConnectTimeout=3", "-o",
                "StrictHostKeyChecking=accept-new", "-o",
                f"UserKnownHostsFile={self.private / 'known-hosts'}", "lab@127.0.0.1", command]

    def guest(self, guest, command, required=True, timeout=60):
        return self.run(self.ssh_command(guest, command), required, timeout)

    def finish(self, error):
        document = {"phase": self.phase, "finishedAt": utc(), "error": error,
                    "guests": GUESTS, "records": self.records,
                    "scope": "Separate clock-use experiment; not a full MSC deployment or a repair of other profiles."}
        (self.output / "observations.json").write_text(json.dumps(document, indent=2) + "\n")
        files = [{"path": path.name, "sha256": digest(path)}
                 for path in sorted(self.output.iterdir()) if path.is_file()]
        (self.output / "manifest.json").write_text(json.dumps({"files": files}, indent=2) + "\n")
        print(json.dumps({"phase": self.phase, "error": error, "observations": len(self.records)}), flush=True)

    def bootstrap(self):
        image = self.images / "noble-server-cloudimg-amd64.img"
        if not image.exists():
            self.run(["curl", "--fail", "--location", "--silent", "--show-error",
                      "--max-time", "600", "--output", image, IMAGE_URL], timeout=610)
        if digest(image) != IMAGE_SHA256:
            raise RuntimeError("The image differs from the recorded official SHA256SUMS entry")
        self.run(["qemu-img", "info", "--output=json", image])
        if not (self.private / "access").exists():
            self.run(["ssh-keygen", "-q", "-t", "ed25519", "-N", "", "-f", self.private / "access"])
        public_key = (self.private / "access.pub").read_text().strip()
        self.run(["date", "-u", "+%s.%N"])
        self.run(["timedatectl", "show"], required=False)
        for bridge in ["tc31red", "tc31gray", "tc31idata", "tc31odata"]:
            self.run(["ip", "link", "add", bridge, "type", "bridge"])
            self.run(["ip", "link", "set", bridge, "up"])
        for guest in GUESTS:
            index = guest["index"]
            folder = self.private / guest["id"]
            folder.mkdir(mode=0o700)
            zone_octet = 203 if guest["zone"] == "red" else 204
            data_octet = 205 if guest["layer"] == "inner" else 206
            last = 11 + index % 2
            mac_clock = f"52:54:31:00:{index:02x}:01"
            mac_data = f"52:54:31:00:{index:02x}:02"
            user_data = {
                "hostname": guest["id"].lower().replace("_", "-"),
                "users": [{"name": "lab", "sudo": "ALL=(ALL) NOPASSWD:ALL",
                           "shell": "/bin/bash", "ssh_authorized_keys": [public_key]}],
                "ssh_pwauth": False, "disable_root": True,
                "package_update": True,
                "packages": ["chrony", "strongswan-swanctl", "charon-systemd",
                             "libstrongswan-extra-plugins", "tcpdump", "python3"],
                "runcmd": [["systemctl", "stop", "chrony"],
                           ["systemctl", "stop", "strongswan"],
                           ["touch", "/var/lib/tdn-clock-bootstrap-ready"]],
            }
            (folder / "user-data").write_text("#cloud-config\n" + json.dumps(user_data) + "\n")
            (folder / "meta-data").write_text(json.dumps({"instance-id": guest["id"],
                                                         "local-hostname": guest["id"].lower()}))
            network = {"version": 2, "ethernets": {
                "management": {"match": {"macaddress": f"52:54:31:00:{index:02x}:00"},
                               "set-name": "mgmt0", "dhcp4": True, "dhcp6": False},
                "clock": {"match": {"macaddress": mac_clock}, "set-name": "clock0",
                          "addresses": [f"10.{zone_octet}.0.{last}/24"]},
                "data": {"match": {"macaddress": mac_data}, "set-name": "data0",
                         "addresses": [f"10.{data_octet}.0.{last}/24"]}}}
            (folder / "network-config").write_text(json.dumps(network))
            self.run(["genisoimage", "-output", folder / "seed.iso", "-volid", "cidata",
                      "-joliet", "-rock", folder / "user-data", folder / "meta-data", folder / "network-config"])
            self.run(["qemu-img", "create", "-f", "qcow2", "-F", "qcow2", "-b", image,
                      folder / "disk.qcow2", "8G"])
            for tap, bridge in [(f"tc31c{index}", "tc31red" if guest["zone"] == "red" else "tc31gray"),
                                (f"tc31d{index}", "tc31idata" if guest["layer"] == "inner" else "tc31odata")]:
                self.run(["ip", "tuntap", "add", "dev", tap, "mode", "tap"])
                self.run(["ip", "link", "set", tap, "master", bridge])
                self.run(["ip", "link", "set", tap, "up"])
            self.run(["qemu-system-x86_64", "-name", guest["id"], "-enable-kvm", "-cpu", "host",
                      "-m", "1536", "-smp", "2", "-drive", f"file={folder / 'disk.qcow2'},if=virtio",
                      "-drive", f"file={folder / 'seed.iso'},media=cdrom,readonly=on",
                      "-netdev", f"user,id=management,hostfwd=tcp:127.0.0.1:{22610 + index}-:22",
                      "-device", f"virtio-net-pci,netdev=management,mac=52:54:31:00:{index:02x}:00",
                      "-netdev", f"tap,id=clock,ifname=tc31c{index},script=no,downscript=no",
                      "-device", f"virtio-net-pci,netdev=clock,mac={mac_clock}",
                      "-netdev", f"tap,id=data,ifname=tc31d{index},script=no,downscript=no",
                      "-device", f"virtio-net-pci,netdev=data,mac={mac_data}", "-display", "none",
                      "-serial", f"file:{folder / 'serial.log'}", "-daemonize", "-pidfile", folder / "qemu.pid"])
        for guest in GUESTS:
            for attempt in range(90):
                ready = self.guest(guest, "test -f /var/lib/tdn-clock-bootstrap-ready", required=False, timeout=10)
                if ready["returncode"] == 0:
                    break
                time.sleep(3)
            if ready["returncode"]:
                raise RuntimeError(f"Guest bootstrap did not finish: {guest['id']}")
            self.guest(guest, "hostname; uname -r; ip -j address; dpkg-query -W chrony strongswan-swanctl charon-systemd; systemctl is-active chrony", required=False)
        self.run(["ip", "-j", "-d", "link", "show"])
        self.run(["date", "-u", "+%s.%N"])


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", required=True)
    parser.add_argument("--phase", choices=["bootstrap"], required=True)
    args = parser.parse_args()
    if os.geteuid() != 0:
        raise SystemExit("Run on the dedicated experiment worker with sudo")
    lab = Lab(args.root, args.phase)
    error = None
    try:
        getattr(lab, args.phase)()
    except Exception as exception:
        error = str(exception)
    finally:
        lab.finish(error)
    if error:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
