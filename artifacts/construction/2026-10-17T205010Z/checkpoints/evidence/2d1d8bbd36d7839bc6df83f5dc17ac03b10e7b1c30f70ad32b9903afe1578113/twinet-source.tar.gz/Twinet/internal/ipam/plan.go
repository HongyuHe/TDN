// Package ipam evaluates a lab's declarative addressing plan.
//
// It replaces the legacy platform's config/subnet_config.sh, a 191-line bash
// file of functions built from undocumented magic offsets (+101, +151, +200,
// 158.X., 157.0.0., 198.X.) that every other script had to `source`, and whose
// values were independently restated in the assignment wiki, the DNS generator,
// the website and the autograder.
//
// Here the plan is data: a set of Go-template expressions evaluated against a
// typed context, with CIDR helpers, and with every result checked for validity
// and overlap.
package ipam

import (
	"fmt"
	"math/big"
	"net/netip"
	"sort"
	"strings"
	"text/template"
)

// Ctx is the binding environment for an addressing expression. Not every field
// is meaningful for every expression; unused ones are simply zero.
type Ctx struct {
	AS        int    // the autonomous system number
	PeerAS    int    // the AS at the other end, for inter-AS links
	RouterID  int    // stable per-AS router index
	PeerID    int    // router index at the other end
	LinkIndex int    // stable index of the link within its scope
	L2ID      int    // layer-2 domain index
	VLAN      int    // VLAN id
	VLANIndex int    // 0-based position of the VLAN within its domain
	IXP       int    // IXP AS number
	Low       int    // the lower of two AS numbers, for symmetric inter-AS prefixes
	High      int    // the higher of two AS numbers
	Host      int    // host index within a subnet
	Name      string // free-form: service name, device name
	Region    string
	// Role and the role indexes describe endpoints emitted by an interior
	// generator. RoleLinkIndex is a deterministic per-generated-interior
	// link ordinal, intended for cidrSubnet-style plans rather than the
	// historic byte-sized LinkIndex convention.
	Role          string
	PeerRole      string
	RoleIndex     int
	PeerRoleIndex int
	RoleLinkIndex int
	LinkClass     string
}

// Plan is a compiled addressing plan. Compilation happens once per lab; the
// templates are then executed many thousands of times, so we parse up front.
type Plan struct {
	tmpl map[string]*template.Template
	src  map[string]string
}

// Field names in the plan. Using constants keeps the compiler honest about
// which expressions exist.
const (
	FieldASBlock          = "as_block"
	FieldASBlockV6        = "as_block_v6"
	FieldRouterLoopback   = "router_loopback"
	FieldRouterLoopbackV6 = "router_loopback_v6"
	FieldRouterRouter     = "router_router"
	FieldRouterRouterRole = "router_router_role"
	FieldRouterHost       = "router_host"
	FieldL2Domain         = "l2_domain"
	FieldL2DomainV6       = "l2_domain_v6"
	FieldL2VLAN           = "l2_vlan"
	FieldL2VLANV6         = "l2_vlan_v6"
	FieldInterAS          = "inter_as"
	FieldIXPPeering       = "ixp_peering"
)

// Compile parses every non-empty expression in the plan.
func Compile(exprs map[string]string) (*Plan, error) {
	p := &Plan{tmpl: map[string]*template.Template{}, src: map[string]string{}}
	names := make([]string, 0, len(exprs))
	for k := range exprs {
		names = append(names, k)
	}
	sort.Strings(names)
	var errs []string
	for _, name := range names {
		expr := exprs[name]
		if strings.TrimSpace(expr) == "" {
			continue
		}
		t, err := template.New(name).Funcs(FuncMap()).Option("missingkey=error").Parse(expr)
		if err != nil {
			errs = append(errs, fmt.Sprintf("addressing.%s: %v", name, err))
			continue
		}
		p.tmpl[name] = t
		p.src[name] = expr
	}
	if len(errs) > 0 {
		return nil, fmt.Errorf("%s", strings.Join(errs, "\n"))
	}
	return p, nil
}

// Has reports whether the plan defines the named expression.
func (p *Plan) Has(name string) bool { _, ok := p.tmpl[name]; return ok }

// Source returns the raw expression text, for diagnostics.
func (p *Plan) Source(name string) string { return p.src[name] }

// Eval evaluates a named expression, returning the rendered string.
func (p *Plan) Eval(name string, ctx Ctx) (string, error) {
	t, ok := p.tmpl[name]
	if !ok {
		return "", fmt.Errorf("addressing.%s is not defined", name)
	}
	var b strings.Builder
	if err := t.Execute(&b, ctx); err != nil {
		return "", fmt.Errorf("addressing.%s: %w", name, err)
	}
	return strings.TrimSpace(b.String()), nil
}

// Prefix evaluates an expression and parses the result as a CIDR prefix.
func (p *Plan) Prefix(name string, ctx Ctx) (netip.Prefix, error) {
	s, err := p.Eval(name, ctx)
	if err != nil {
		return netip.Prefix{}, err
	}
	pf, err := netip.ParsePrefix(s)
	if err != nil {
		return netip.Prefix{}, fmt.Errorf("addressing.%s produced %q which is not a CIDR prefix: %w", name, s, err)
	}
	return pf.Masked(), nil
}

// Addr evaluates an expression and parses the result as an address with prefix
// length, e.g. "12.0.1.1/24". The address is *not* masked.
func (p *Plan) Addr(name string, ctx Ctx) (netip.Prefix, error) {
	s, err := p.Eval(name, ctx)
	if err != nil {
		return netip.Prefix{}, err
	}
	pf, err := netip.ParsePrefix(s)
	if err != nil {
		return netip.Prefix{}, fmt.Errorf("addressing.%s produced %q which is not addr/len: %w", name, s, err)
	}
	return pf, nil
}

// ---------------------------------------------------------------------------
// Overlap detection
// ---------------------------------------------------------------------------

// Claim records that some object claims a prefix, so conflicts can be reported
// with both claimants named. The legacy platform had no such check: two
// overlapping subnets simply produced a network that misbehaved at runtime.
type Claim struct {
	Prefix netip.Prefix
	Owner  string // human-readable, e.g. "as12 link ATL--BOS"
	Field  string // which plan expression produced it
	// Scope names the autonomous system this claim belongs to, "as12", or is
	// empty for a claim that belongs to no single system -- an inter-AS link,
	// or a segment spanning two systems.
	//
	// Without it an aggregate excused any overlap it contained, whoever it
	// belonged to, so AS 2 could address an internal link out of AS 1's block
	// and the plan validated. Every packet for it would be drawn towards AS 1.
	Scope string
}

// Registry accumulates claims and reports overlaps.
type Registry struct {
	claims []Claim
	// exempt holds the aggregates, each with the system it belongs to: an
	// aggregate contains its own system's subnets by design, and nobody
	// else's by mistake.
	exempt []Claim
}

// NewRegistry creates an empty registry.
func NewRegistry() *Registry { return &Registry{} }

// Exempt marks a prefix as scope's aggregate: scope's own claims may fall
// inside it.
func (r *Registry) Exempt(p netip.Prefix, scope string) {
	r.exempt = append(r.exempt, Claim{Prefix: p.Masked(), Scope: scope})
}

// Claim records a claim.
func (r *Registry) Claim(p netip.Prefix, owner, field, scope string) {
	r.claims = append(r.claims, Claim{
		Prefix: p.Masked(), Owner: owner, Field: field, Scope: scope,
	})
}

// Conflict describes two claims that overlap.
type Conflict struct {
	A, B Claim
}

func (c Conflict) String() string {
	return fmt.Sprintf("prefix %s (%s, from addressing.%s) overlaps %s (%s, from addressing.%s)",
		c.A.Prefix, c.A.Owner, c.A.Field, c.B.Prefix, c.B.Owner, c.B.Field)
}

// Conflicts returns every pair of overlapping claims, excluding pairs where one
// side is an exempt aggregate.
//
// Claims are sorted by start address, so the scan for a given claim can stop as
// soon as it reaches one that starts beyond the claim's last address: for
// prefixes, containment and disjointness are the only possibilities, so nothing
// later can reach back. Near-linear in practice; quadratic only in the
// pathological case of one prefix containing everything.
func (r *Registry) Conflicts() []Conflict {
	claims := append([]Claim{}, r.claims...)
	sort.Slice(claims, func(i, j int) bool {
		a, b := claims[i].Prefix, claims[j].Prefix
		if a.Addr() != b.Addr() {
			return a.Addr().Less(b.Addr())
		}
		return a.Bits() < b.Bits()
	})
	var out []Conflict
	for i := 0; i < len(claims); i++ {
		for j := i + 1; j < len(claims); j++ {
			a, b := claims[i], claims[j]
			if a.Prefix.Addr().Is4() != b.Prefix.Addr().Is4() {
				continue
			}
			// Sorted by start address: once b starts beyond a's end, and beyond
			// every subsequent claim's start, no further j can overlap i.
			if !overlaps(a.Prefix, b.Prefix) {
				if b.Prefix.Addr().Less(lastAddr(a.Prefix)) || b.Prefix.Addr() == lastAddr(a.Prefix) {
					continue
				}
				break
			}
			if r.exemptPair(a, b) {
				continue
			}
			out = append(out, Conflict{A: a, B: b})
		}
	}
	return out
}

// exemptPair reports whether an overlap between two claims is the intended one.
//
// An aggregate exists to contain things, so a claim inside it is not a
// conflict. But that is the only overlap it excuses. The rule used to be "skip
// if either side is exempt", which also excused two aggregates overlapping each
// other -- so an AS given 10.0.0.0/8 and another given 10.0.0.0/9 both
// validated, and every address in the second AS belonged to the first as well.
// That is the single worst thing an addressing plan can do, and it was the one
// overlap the checker was guaranteed not to report.
func (r *Registry) exemptPair(a, b Claim) bool {
	aEx, aOK := r.aggregateFor(a.Prefix)
	bEx, bOK := r.aggregateFor(b.Prefix)
	switch {
	case aOK && bOK:
		// Two aggregates. Always a conflict: neither is inside the other by
		// arrangement, and if one is, the arrangement is the mistake.
		return false
	case aOK:
		return contains(a.Prefix, b.Prefix) && aEx.Scope == b.Scope
	case bOK:
		return contains(b.Prefix, a.Prefix) && bEx.Scope == a.Scope
	default:
		return false
	}
}

// contains reports whether outer covers inner, including when they are equal:
// an AS whose aggregate is exactly one subnet is unusual but not wrong.
func contains(outer, inner netip.Prefix) bool {
	return outer.Bits() <= inner.Bits() && outer.Contains(inner.Addr())
}

func (r *Registry) aggregateFor(p netip.Prefix) (Claim, bool) {
	for _, e := range r.exempt {
		if e.Prefix == p {
			return e, true
		}
	}
	return Claim{}, false
}

func overlaps(a, b netip.Prefix) bool {
	return a.Overlaps(b)
}

func lastAddr(p netip.Prefix) netip.Addr {
	a := p.Masked().Addr()
	bits := a.BitLen()
	host := bits - p.Bits()
	if host == 0 {
		return a
	}
	n := addrToBig(a)
	size := new(big.Int).Lsh(big.NewInt(1), uint(host))
	n.Add(n, size)
	n.Sub(n, big.NewInt(1))
	return bigToAddr(n, a.Is4())
}

func addrToBig(a netip.Addr) *big.Int {
	b := a.As16()
	return new(big.Int).SetBytes(b[:])
}

func bigToAddr(n *big.Int, is4 bool) netip.Addr {
	var buf [16]byte
	nb := n.Bytes()
	if len(nb) > 16 {
		nb = nb[len(nb)-16:]
	}
	copy(buf[16-len(nb):], nb)
	a := netip.AddrFrom16(buf)
	if is4 {
		return a.Unmap()
	}
	return a
}
