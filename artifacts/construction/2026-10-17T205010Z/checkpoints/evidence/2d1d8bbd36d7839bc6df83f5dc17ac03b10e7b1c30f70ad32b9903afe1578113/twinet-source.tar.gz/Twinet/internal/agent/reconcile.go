package agent

import (
	"context"
	"errors"
	"fmt"
	"log/slog"
	"sort"
	"strconv"
	"strings"
	"time"

	"github.com/HongyuHe/twinet/internal/deploy"
	"github.com/HongyuHe/twinet/internal/limiter"
	"github.com/HongyuHe/twinet/internal/model"
	"github.com/HongyuHe/twinet/internal/plan"
	"github.com/HongyuHe/twinet/internal/render"
	rt "github.com/HongyuHe/twinet/internal/runtime"
)

// Reconciliation is event driven. Audits are deliberately much less frequent
// than the old once-a-minute Docker-inspect-and-exec sweep: lifecycle events
// repair the normal failure path promptly, while samples and full audits catch
// a lost event stream or an out-of-band change.
const (
	reconcileEvery     = 5 * time.Minute
	reconcileFullEvery = 10 * time.Minute
	reconcileRetryMin  = 100 * time.Millisecond
	reconcileRetryMax  = 5 * time.Second
	// semanticSampleWidth bounds the cheap dynamic-state audit fan-out while
	// avoiding a one-device-per-five-minutes blind spot that left an idle
	// recovered host broken for hours.
	semanticSampleWidth = 8
)

type deviceHealth string

const (
	healthHealthy deviceHealth = "healthy"
	healthBroken  deviceHealth = "broken"
	healthUnknown deviceHealth = "unknown"
	healthPartial deviceHealth = "partial"
)

type deviceObservation struct {
	Health      deviceHealth
	Reason      string
	State       rt.State
	SpecMatches bool
}

// reconcileLoop repairs devices that have lost their wiring.
//
// A container that restarts -- because someone typed `docker restart`, because
// it ran out of memory, because the host rebooted -- comes back with an empty
// network namespace. Every interface is gone; only lo and the kernel's sit0
// remain. The container is running, its health check may even pass, and it can
// reach nothing at all.
//
// Nothing used to notice. The wiring is idempotent and a deploy would put it
// back, but a deploy only runs when a person runs one, and the person has no
// reason to until the symptom is reported. Between those two moments the device
// is a black hole in the middle of somebody's assignment, and the most likely
// conclusion they draw is that their own configuration is at fault.
func (s *Server) reconcileLoop(ctx context.Context) {
	s.startReconcileWorkers(ctx)
	go s.runtimeEventLoop(ctx)

	// A new agent has no event history before it subscribed. A sampled startup
	// pass closes that gap without immediately turning a cold restart into one
	// exec per device.
	s.reconcileSample(ctx)
	sample := time.NewTicker(reconcileEvery)
	full := time.NewTicker(reconcileFullEvery)
	defer sample.Stop()
	defer full.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-sample.C:
			s.reconcileSample(ctx)
		case <-full.C:
			s.reconcileOnce(ctx)
		}
	}
}

// runtimeEventSource returns the native event source when the runtime offers
// one. Tests often inject a Runtime directly, so the fallback is intentional.
func (s *Server) runtimeEventSource() rt.EventSource {
	if s.eventSource != nil {
		return s.eventSource
	}
	source, _ := s.rt.(rt.EventSource)
	return source
}

// runtimeEventLoop reconnects after every terminal event-stream error. A
// stream ending is not proof the host is healthy, so the sampled/full audits
// remain active while reconnect is retried with a bounded delay.
func (s *Server) runtimeEventLoop(ctx context.Context) {
	source := s.runtimeEventSource()
	if source == nil {
		s.recordEvent("", "", "runtime", "", "event_subscription", "unknown",
			"runtime does not expose lifecycle events; audit backstop is active")
		return
	}
	retry := reconcileRetryMin
	for {
		if ctx.Err() != nil {
			return
		}
		streamCtx, cancel := context.WithCancel(ctx)
		start := time.Now()
		subscription := source.Subscribe(streamCtx, rt.EventFilter{
			Labels: map[string]string{deploy.LabelManaged: "true"},
		})
		s.metricRegistry().observeRuntime("subscribe", time.Since(start), nil)
		s.recordEvent("", "", "runtime", "", "event_subscription", "success", "connected")

		events, errs := subscription.Events, subscription.Errors
		terminal := error(nil)
		for events != nil || errs != nil {
			select {
			case <-ctx.Done():
				cancel()
				return
			case event, ok := <-events:
				if !ok {
					events = nil
					continue
				}
				s.metricRegistry().observeRuntimeEvent(string(event.Action))
				s.handleRuntimeEvent(ctx, event)
			case err, ok := <-errs:
				if !ok {
					errs = nil
					continue
				}
				terminal = err
				cancel()
			}
		}
		cancel()
		if ctx.Err() != nil {
			return
		}
		if terminal == nil {
			terminal = rt.ErrEventStreamClosed
		}
		s.metricRegistry().observeRuntime("subscribe", 0, terminal)
		s.recordEvent("", "", "runtime", "", "event_subscription", "error", terminal.Error())
		if time.Since(start) >= reconcileRetryMax {
			retry = reconcileRetryMin
		}
		select {
		case <-ctx.Done():
			return
		case <-time.After(retry):
		}
		retry *= 2
		if retry > reconcileRetryMax {
			retry = reconcileRetryMax
		}
	}
}

func (s *Server) handleRuntimeEvent(ctx context.Context, event rt.Event) {
	lab := event.Labels[deploy.LabelLab]
	if lab == "" {
		lab = s.labOfContainer(event.Name)
	}
	if lab == "" {
		return
	}
	device := event.Labels[deploy.LabelDeviceID]
	if device == "" {
		device = event.Name
	}
	s.recordEvent(lab, event.Labels[deploy.LabelGen], "runtime", "",
		"container."+string(event.Action), "scheduled", device)
	s.queueReconcile(ctx, lab, device)
}

type reconcileRequest struct {
	lab    string
	device string
	force  bool
}

type forceSemanticRepairKey struct{}

// startReconcileWorkers bounds event-triggered repair fan-out independently
// of the runtime limiter. A Docker reconnect can replay many events; it must
// not create one goroutine per historical device.
func (s *Server) startReconcileWorkers(ctx context.Context) {
	s.reconcileWorkersOnce.Do(func() {
		s.reconcileMu.Lock()
		s.reconcileQueue = make(chan reconcileRequest, 1024)
		s.reconcileContext = ctx
		if s.reconcilePending == nil {
			s.reconcilePending = map[string]bool{}
		}
		queue := s.reconcileQueue
		s.reconcileMu.Unlock()
		for range 4 {
			go func() {
				for {
					select {
					case <-ctx.Done():
						return
					case request := <-queue:
						s.reconcileTarget(ctx, request)
						s.reconcileMu.Lock()
						delete(s.reconcilePending, repairKey(request.lab, request.device))
						s.reconcileMu.Unlock()
					}
				}
			}()
		}
	})
}

func (s *Server) queueReconcile(ctx context.Context, lab, device string) {
	if lab == "" {
		return
	}
	if reason := s.ordinaryMaintenanceSuppression(lab); reason != "" {
		s.metricRegistry().observeRepair("recovery")
		return
	}
	s.reconcileMu.Lock()
	queue := s.reconcileQueue
	if queue == nil {
		s.reconcileMu.Unlock()
		return
	}
	key := repairKey(lab, device)
	if s.reconcilePending[key] {
		s.reconcileMu.Unlock()
		return
	}
	s.reconcilePending[key] = true
	s.reconcileMu.Unlock()
	request := reconcileRequest{lab: lab, device: device}
	select {
	case queue <- request:
		s.metricRegistry().observeRepair("scheduled")
	case <-ctx.Done():
		s.reconcileMu.Lock()
		delete(s.reconcilePending, key)
		s.reconcileMu.Unlock()
	default:
		// The full audit is the recovery path for a queue overflow. Do not
		// block Docker event intake behind a storm of duplicate deaths.
		s.reconcileMu.Lock()
		delete(s.reconcilePending, key)
		s.reconcileMu.Unlock()
		s.recordEvent(lab, "", "reconcile", "", "repair_queue", "backoff",
			"event repair queue is full; audit backstop will retry")
	}
}

func (s *Server) queueReconcileAfter(lab, device string, delay time.Duration) {
	if delay <= 0 {
		return
	}
	s.reconcileMu.Lock()
	ctx := s.reconcileContext
	queue := s.reconcileQueue
	s.reconcileMu.Unlock()
	if ctx == nil || queue == nil {
		return
	}
	go func() {
		timer := time.NewTimer(delay)
		defer timer.Stop()
		select {
		case <-ctx.Done():
			return
		case <-timer.C:
			s.queueReconcile(ctx, lab, device)
		}
	}()
}

func (s *Server) reconcileTarget(ctx context.Context, request reconcileRequest) {
	if reason := s.ordinaryMaintenanceSuppression(request.lab); reason != "" {
		s.metricRegistry().observeRepair("recovery")
		s.recordEvent(request.lab, "", "reconcile", "", "repair_skipped", "recovery", reason)
		return
	}
	s.mu.Lock()
	top := s.current[request.lab]
	s.mu.Unlock()
	if top == nil {
		return
	}
	if who := s.heldBy(request.lab); who != "" {
		s.metricRegistry().observeRepair("held")
		s.recordEvent(request.lab, "", "reconcile", "", "repair_skipped", "held", who)
		return
	}
	if who := s.mutationLeaseHolder(request.lab); who != "" {
		s.metricRegistry().observeRepair("held")
		s.recordEvent(request.lab, "", "reconcile", "", "repair_skipped", "held", who)
		return
	}
	var devices []*model.Device
	for _, device := range top.SortedDevices() {
		if device.Node != s.cfg.Node {
			continue
		}
		if request.device == "" || request.device == device.ID || request.device == device.Container {
			devices = append(devices, device)
		}
	}
	if len(devices) == 0 {
		return
	}
	broken := make([]*model.Device, 0, len(devices))
	for _, device := range devices {
		if s.isExempt(request.lab, device.ID) {
			s.metricRegistry().observeRepair("exempt")
			continue
		}
		observation := s.observeDevice(ctx, request.lab, device, true)
		s.rememberHealth(request.lab, device.ID, observation)
		switch observation.Health {
		case healthHealthy:
			s.repairSucceeded(request.lab, device.ID)
		case healthBroken:
			broken = append(broken, device)
		case healthUnknown:
			s.metricRegistry().observeRepair("unknown")
		}
	}
	if len(broken) == 0 {
		return
	}
	repairCtx, cancel := context.WithCancel(ctx)
	if request.force {
		repairCtx = context.WithValue(repairCtx, forceSemanticRepairKey{}, true)
	}
	defer cancel()
	opID, done, err := s.acquireOperation(request.lab, "reconcile", cancel)
	if err != nil {
		return
	}
	defer s.releaseOperation(request.lab, opID, done)
	s.repairLab(repairCtx, top, broken)
}

// rememberHealth keeps only the last bounded state per device. It makes a
// partial or unreadable observation visible in the event stream without
// emitting an event on every sampled audit.
func (s *Server) rememberHealth(lab, device string, observation deviceObservation) {
	key := repairKey(lab, device)
	s.mu.Lock()
	if s.health == nil {
		s.health = map[string]deviceObservation{}
	}
	previous, known := s.health[key]
	s.health[key] = observation
	s.mu.Unlock()
	if known && previous.Health == observation.Health && previous.Reason == observation.Reason {
		return
	}
	result := string(observation.Health)
	if observation.Health == healthHealthy {
		result = "success"
	}
	s.recordEvent(lab, "", "reconcile", "", "device_health", result,
		device+": "+observation.Reason)
}

func (s *Server) reconcileOnce(ctx context.Context) {
	s.mu.Lock()
	labs := make(map[string]*model.Topology, len(s.current))
	for name, top := range s.current {
		labs[name] = top
	}
	s.mu.Unlock()

	for name, top := range labs {
		if top == nil {
			continue
		}
		// An external operation -- grading, most often -- has asked to be left
		// alone with this lab. It is deliberately manipulating devices, and a
		// device mid-manipulation is indistinguishable from a broken one.
		if who := s.heldBy(name); who != "" {
			slog.Debug("leaving lab alone while it is held",
				"lab", name, "holder", who)
			continue
		}
		if who := s.mutationLeaseHolder(name); who != "" {
			slog.Debug("leaving lab alone while a fenced mutation is active",
				"lab", name, "holder", who)
			continue
		}
		if why := s.ordinaryMaintenanceSuppression(name); why != "" {
			slog.Debug("leaving lab alone while durable recovery owns it",
				"lab", name, "reason", why)
			continue
		}
		if s.ephemeralExpired(name) {
			// Reclamation is owed on this lab. Repairing it would spend the
			// very capacity the reclamation exists to return, and would fight
			// the reaper for the operation lease.
			slog.Debug("leaving an expired ephemeral lab alone until it is reclaimed", "lab", name)
			continue
		}
		// The survey runs without the lab lock. Holding it for the whole scan
		// made a background maintenance task block the operator: a deploy
		// arriving mid-sweep was refused with "another operation is already
		// running", for a sweep that in the normal case finds nothing to do.
		// Reading a container's interface list changes nothing, so it does not
		// need to exclude anyone.
		broken := s.survey(ctx, top)
		if len(broken) == 0 {
			continue
		}
		// Repairing does change things, so it takes the lock -- and yields
		// immediately if a deploy or a destroy holds it, because whatever they
		// are doing is a better answer than this loop's.
		repairCtx, cancel := context.WithCancel(ctx)
		opID, done, err := s.acquireOperation(name, "reconcile", cancel)
		if err != nil {
			cancel()
			continue
		}
		s.repairLab(repairCtx, top, broken)
		cancel()
		s.releaseOperation(name, opID, done)
	}
}

// reconcileSample checks one local device from each lab. It is cheap enough
// to run while an event stream is reconnecting, while reconcileOnce remains
// the low-frequency complete backstop.
func (s *Server) reconcileSample(ctx context.Context) {
	s.mu.Lock()
	labs := make(map[string]*model.Topology, len(s.current))
	for name, top := range s.current {
		labs[name] = top
	}
	s.mu.Unlock()
	for name, top := range labs {
		if top == nil || s.heldBy(name) != "" || s.mutationLeaseHolder(name) != "" ||
			s.ordinaryMaintenanceSuppression(name) != "" || s.ephemeralExpired(name) {
			continue
		}
		var devices []*model.Device
		for _, device := range top.SortedDevices() {
			if device.Node == s.cfg.Node {
				devices = append(devices, device)
			}
		}
		if len(devices) == 0 {
			continue
		}
		slot := int(time.Now().Unix() / int64(reconcileEvery/time.Second))
		start := (slot * semanticSampleWidth) % len(devices)
		width := semanticSampleWidth
		if width > len(devices) {
			width = len(devices)
		}
		for offset := 0; offset < width; offset++ {
			s.queueReconcile(ctx, name, devices[(start+offset)%len(devices)].ID)
		}
	}
}

// survey reports which of this node's devices have lost their wiring.
func (s *Server) survey(ctx context.Context, top *model.Topology) []*model.Device {
	var broken []*model.Device
	for _, d := range top.Devices {
		if d.Node != s.cfg.Node {
			continue
		}
		// A device that was broken on purpose is not a device to repair. The
		// record lives on this node rather than in the container, because a
		// marker inside the device under test tells an agent being evaluated
		// on root-cause analysis that a fault was injected.
		if s.isExempt(top.Name, d.ID) {
			s.metricRegistry().observeRepair("exempt")
			continue
		}
		observation := s.observeDevice(ctx, top.Name, d, true)
		s.rememberHealth(top.Name, d.ID, observation)
		switch observation.Health {
		case healthHealthy:
			// A device which comes back by itself must not retain the failure
			// history accumulated while it was unavailable.
			s.repairSucceeded(top.Name, d.ID)
		case healthUnknown:
			s.metricRegistry().observeRepair("unknown")
		case healthPartial:
			// Partial is explicit and is never called healthy. It receives a
			// short deploy grace, then observeDevice upgrades it to broken.
		case healthBroken:
			broken = append(broken, d)
		}
	}
	return broken
}

// repairLab rewires the devices whose namespaces have been emptied, and puts
// back the configuration they were holding.
func (s *Server) repairLab(ctx context.Context, top *model.Topology, broken []*model.Device) {
	// The hold and fence checks above the survey are intentionally repeated
	// after acquiring the local repair lease. A grader or controller can take
	// either lease in the gap; repairing beneath it would mutate a submission
	// or mix deployment generations.
	if who := s.heldBy(top.Name); who != "" {
		s.metricRegistry().observeRepair("held")
		s.recordEvent(top.Name, "", "reconcile", "", "repair_skipped", "held", who)
		return
	}
	if who := s.mutationLeaseHolder(top.Name); who != "" {
		s.metricRegistry().observeRepair("held")
		s.recordEvent(top.Name, "", "reconcile", "", "repair_skipped", "held", who)
		return
	}
	if reason := s.ordinaryMaintenanceSuppression(top.Name); reason != "" {
		s.metricRegistry().observeRepair("recovery")
		s.recordEvent(top.Name, "", "reconcile", "", "repair_skipped", "recovery", reason)
		return
	}
	if s.repairHook != nil {
		s.repairHook(ctx, top, broken)
		return
	}

	// Re-checked under the lock: the survey ran without it, so a deploy may
	// have repaired these already in the meantime, and rewiring a device that
	// is now fine would undo work rather than restore it.
	still := make([]*model.Device, 0, len(broken))
	for _, d := range broken {
		if s.isExempt(top.Name, d.ID) {
			s.metricRegistry().observeRepair("exempt")
			continue
		}
		observation := s.observeDevice(ctx, top.Name, d, false)
		s.rememberHealth(top.Name, d.ID, observation)
		if observation.Health == healthHealthy {
			s.repairSucceeded(top.Name, d.ID)
			continue
		}
		if observation.Health == healthBroken {
			still = append(still, d)
		}
	}
	broken = still
	if len(broken) == 0 {
		return
	}

	names := make([]string, len(broken))
	for i, d := range broken {
		names[i] = d.ID
	}
	reason := s.observeDevice(ctx, top.Name, broken[0], false).Reason
	slog.Warn("devices are not as the lab says they should be; repairing",
		"lab", top.Name, "devices", strings.Join(names, ","),
		"reason", reason)

	// The engine needs a renderer.
	//
	// Without one, configure() returns success having done nothing, so a
	// repaired router came back with its cables and none of its configuration:
	// no addresses on the VLAN sub-interfaces, no tunnel, and FRR not running.
	// The device then had enough interfaces to look healthy to the detector
	// below, so it was never revisited. A restarted router stayed broken
	// forever while the logs said it had been repaired.
	//
	// Rendered in whatever mode the lab was applied with.
	//
	// It was always platform mode, on the reasoning that anything a student
	// wrote comes back from the snapshot store. That is right for a teaching
	// lab and wrong for a lab deployed at the reference, which is what every
	// grading run uses: repairing one router there re-rendered it without the
	// reference solution, so a class was graded against a network in which
	// some systems had quietly stopped being the answer they were meant to be.
	// Nothing reported it, because the repair itself succeeded.
	// The mode alone is not enough. A private grading harness is deployed
	// solved *except* for the one system being marked, which keeps the
	// platform's starting configuration; replaying only "solve" rebuilds that
	// system holding the reference answer, for the student whose work is being
	// marked against it, and reports the repair as a success.
	s.mu.Lock()
	mode := s.modes[top.Name]
	ungraded := s.ungraded[top.Name]
	s.mu.Unlock()
	eng := s.autoRepairEngine(top)
	for _, d := range broken {
		if reason := s.ordinaryMaintenanceSuppression(top.Name); reason != "" {
			s.metricRegistry().observeRepair("recovery")
			s.recordEvent(top.Name, "", "reconcile", "", "repair_skipped", "recovery", reason)
			return
		}
		if s.givingUpOn(top.Name, d.ID) && !forceSemanticRepair(ctx) {
			s.metricRegistry().observeRepair("backoff")
			s.recordEvent(top.Name, "", "reconcile", "", "repair_deferred", "backoff",
				d.ID+" remains in bounded retry backoff")
			continue
		}
		observation := s.observeDevice(ctx, top.Name, d, false)
		if observation.Health != healthBroken {
			if observation.Health == healthHealthy {
				s.repairSucceeded(top.Name, d.ID)
			}
			continue
		}
		if isSemanticOnlyDrift(observation.Reason) {
			if reason := s.semanticRepairTerminalReason(top.Name, d.ID); reason != "" && !forceSemanticRepair(ctx) {
				// Terminal is terminal. The device has had its bounded cycle
				// of local repairs, the drift outlived every one of them, and
				// the node has already said so loudly. Retrying for ever
				// would keep a fault that needs a human looking like work in
				// progress.
				s.metricRegistry().observeRepair("terminal")
				s.recordEvent(top.Name, "", "reconcile", "", "semantic_repair_terminal", "error",
					d.ID+": "+reason)
				continue
			}
			semanticCtx, cancel := context.WithTimeout(ctx, semanticRepairTimeout)
			repairErr := s.repairSemanticDrift(semanticCtx, eng, top, d, observation)
			cancel()
			if repairErr == nil {
				s.repairSucceeded(top.Name, d.ID)
				s.metricRegistry().observeRepair("success")
				s.recordEvent(top.Name, "", "reconcile", "", "semantic_repair", "success", d.ID)
				continue
			}
			s.recordEvent(top.Name, "", "reconcile", "", "semantic_repair", "error",
				d.ID+": "+repairErr.Error())
			s.deferSemanticRepair(top.Name, d.ID, repairErr.Error())
			continue
		}
		class := deviceChangeClass(observation)
		s.recordEvent(top.Name, "", "reconcile", "", "change_plan", "scheduled",
			d.ID+"="+string(class))
		if reason := s.ordinaryMaintenanceSuppression(top.Name); reason != "" {
			s.metricRegistry().observeRepair("recovery")
			return
		}
		if err := s.reviveDevice(ctx, eng, top, d, observation); err != nil {
			s.repairFailed(top.Name, d.ID, "container lifecycle repair failed", err)
			s.recordEvent(top.Name, "", "reconcile", "", "repair", "error",
				d.ID+": "+err.Error())
			continue
		}
		if observation.State != rt.StateRunning || !observation.SpecMatches {
			if err := s.waitForJoinable(ctx, d.Container); err != nil {
				s.repairFailed(top.Name, d.ID, "container did not become joinable after lifecycle repair", err)
				s.recordEvent(top.Name, "", "reconcile", "", "repair", "error",
					d.ID+": "+err.Error())
				continue
			}
		}
		// A router whose cables are all present and whose daemons have died
		// needs the daemons started, not the device rebuilt. Rewiring it would
		// re-render its configuration in platform mode, which in a lab
		// deployed at the reference throws the reference solution away -- a
		// far worse outcome than the fault being repaired.
		//
		// A sidecar left behind in the namespace of a router that has since
		// restarted is a different fault with a different repair. Its daemons
		// are running and its vty answers; what is wrong is where it is. Only
		// the sidecar is rebuilt, so the student's router and everything in it
		// survive the repair untouched.
		if strings.HasPrefix(observation.Reason, controlNamespaceSplit) {
			if err := s.rebindControlSidecar(ctx, eng, top, d); err != nil {
				s.repairFailed(top.Name, d.ID, "FRR control sidecar could not be rebound", err)
				s.recordEvent(top.Name, "", "reconcile", "", "repair", "error",
					d.ID+": "+err.Error())
				// Never rewire or re-render the router because its sidecar
				// landed in the wrong namespace. The next attempt follows the
				// ordinary bounded backoff.
				continue
			}
			s.repairSucceeded(top.Name, d.ID)
			s.metricRegistry().observeRepair("success")
			s.recordEvent(top.Name, "", "reconcile", "", "repair", "success",
				d.ID+" FRR control sidecar rebound to the router's network namespace")
			slog.Info("FRR control sidecar rebound to its router's network namespace",
				"device", d.ID)
			continue
		}
		if why := observation.Reason; strings.HasPrefix(why, daemonsDown) {
			if s.requiresFRRControl(d) {
				controlCtx, cancel := context.WithTimeout(ctx, controlDaemonRepairTimeout)
				err := eng.EnsureRuntimeSupport(controlCtx, top, d)
				if err == nil {
					err = s.startDaemons(controlCtx, top.Name, d)
				}
				if err != nil && controlCtx.Err() == nil {
					err = eng.RecreateRuntimeSupport(controlCtx, top, d)
					if err == nil {
						err = s.startDaemons(controlCtx, top.Name, d)
					}
				}
				if err == nil {
					err = s.confirmDaemonRepair(controlCtx, top, d)
				}
				cancel()
				if err == nil {
					s.repairSucceeded(top.Name, d.ID)
					s.metricRegistry().observeRepair("success")
					s.recordEvent(top.Name, "", "reconcile", "", "repair", "success",
						d.ID+" FRR control sidecar repaired")
					continue
				}
				s.repairFailed(top.Name, d.ID, "FRR control sidecar repair failed", err)
				s.recordEvent(top.Name, "", "reconcile", "", "repair", "error",
					d.ID+": "+err.Error())
				// Never rewire/re-render the primary as a fallback for a
				// control-PID namespace fault. One bounded control repair is
				// enough; the next attempt follows normal backoff.
				continue
			}
			if err := s.startDaemons(ctx, top.Name, d); err == nil {
				if err := s.confirmDaemonRepair(ctx, top, d); err == nil {
					s.repairSucceeded(top.Name, d.ID)
					s.metricRegistry().observeRepair("success")
					s.recordEvent(top.Name, "", "reconcile", "", "repair", "success",
						d.ID+" routing daemons restarted")
					slog.Info("routing daemons restarted", "device", d.ID)
					continue
				}
			} else {
				// Starting is futile when the reason they are not running is
				// that the configuration says not to run them.
				//
				// A container recreated by an interrupted deployment comes up
				// with the image's own /etc/frr/daemons, in which bgpd, ospfd
				// and ldpd are all off. frrinit.sh then honours that file and
				// starts nothing, the repair reports failure three times, and
				// the device is abandoned -- a router with no BGP in a lab
				// nobody is watching, found here as one AS whose customer
				// session had been down for forty minutes with every ping
				// between them succeeding. Rewiring re-renders the files,
				// which is what such a device actually needs.
				slog.Error("routing daemons could not be started; rebuilding the device so "+
					"its configuration is written again", "device", d.ID, "err", err)
			}
		}
		if reason := s.ordinaryMaintenanceSuppression(top.Name); reason != "" {
			s.metricRegistry().observeRepair("recovery")
			return
		}
		// One rewire, and everything it disturbs. Rewiring this device rebuilds
		// its neighbours' ends of the cables between them, so their state is
		// saved first and put back afterwards; repairing this device alone is
		// what left three routers holding bare interfaces while the repair
		// reported success.
		//
		// The suppression re-check is kept where it was, between the wiring
		// and the replay: a rollback may take the lab in that window and a
		// student's snapshot must not be replayed underneath it.
		err := s.rewireWithPeers(ctx, rewireRequest{
			engine: eng, top: top, device: d,
			mode: render.Mode(mode), ungraded: ungraded,
			beforeReplay: func() error {
				if reason := s.ordinaryMaintenanceSuppression(top.Name); reason != "" {
					return errRepairSuppressed
				}
				return nil
			},
		})
		if errors.Is(err, errRepairSuppressed) {
			s.metricRegistry().observeRepair("recovery")
			return
		}
		if err != nil {
			s.repairFailed(top.Name, d.ID, rewireFailureLabel(err), err)
			s.recordEvent(top.Name, "", "reconcile", "", "repair", "error",
				d.ID+": "+err.Error())
			continue
		}
		// A rewire gives the router its cables back; it does nothing for a
		// control sidecar that is still attached to the namespace the router
		// had before it restarted. Rebinding it here rather than on a later
		// retry is what lets a SIGKILLed router recover its control plane
		// inside a single repair.
		if err := s.repairControlNamespaceAfterRewire(ctx, eng, top, d); err != nil {
			s.repairFailed(top.Name, d.ID, "FRR control sidecar could not be rebound after rewiring", err)
			s.recordEvent(top.Name, "", "reconcile", "", "repair", "error",
				d.ID+": "+err.Error())
			continue
		}
		// Confirmed, not assumed. A repair that reports success without being
		// checked is how the previous version of this loop claimed to have
		// fixed routers it had left with no addresses and no routing daemon.
		after := s.observeDevice(ctx, top.Name, d, false)
		s.rememberHealth(top.Name, d.ID, after)
		if after.Health != healthHealthy {
			reason := after.Reason
			if reason == "" {
				reason = string(after.Health)
			}
			s.repairFailed(top.Name, d.ID, "device is still not right after being repaired",
				errors.New(reason))
			s.recordEvent(top.Name, "", "reconcile", "", "repair", "error",
				d.ID+": "+reason)
			continue
		}
		s.repairSucceeded(top.Name, d.ID)
		s.metricRegistry().observeRepair("success")
		s.recordEvent(top.Name, "", "reconcile", "", "repair", "success", d.ID)
		slog.Info("device repaired and its configuration put back", "device", d.ID)
	}
}

// repairSemanticDrift performs one bounded local repair cycle for a device
// whose containers and cables are present but whose network semantics are not
// what the topology says they should be.
//
// The steps escalate and every one of them is scoped to this device: restore
// the cross-node bindings its own links need, reapply its rendered
// configuration, and -- only for drift this node provably owns -- rewire the
// device itself. Nothing here may replace a shared trunk or touch a device
// that was not reported broken, because the fault this exists to repair was
// caused by exactly that: a single endpoint's repair deleting the bindings of
// every other link on the same node pair.
//
// It returns nil only after re-observing the device as healthy, so a repair
// can never report success against evidence it did not check.
func (s *Server) repairSemanticDrift(ctx context.Context, eng *deploy.Engine,
	top *model.Topology, d *model.Device, observation deviceObservation,
) error {
	if isSemanticOnlyDrift(observation.Reason) && !locallyRepairableDrift(observation.Reason) {
		// A missing remote route or session is not a local configuration
		// defect. Reloading this router cannot create the peer's interface; it
		// only resets healthy sessions and can keep the whole fabric from ever
		// converging. Re-observe it through the bounded cycle and escalate if
		// the distributed condition persists, without mutating local state.
		return errors.New(semanticDriftReason(observation, observation))
	}
	if err := s.restoreDeviceOverlayBindings(ctx, eng, top, d); err != nil {
		return err
	}
	if err := eng.ReconfigureDevice(ctx, d); err != nil {
		return err
	}
	if err := s.confirmDaemonRepair(ctx, top, d); err != nil {
		return err
	}
	after := s.observeDevice(ctx, top.Name, d, false)
	s.rememberHealth(top.Name, d.ID, after)
	if after.Health == healthHealthy {
		return nil
	}
	if !isSemanticOnlyDrift(after.Reason) || !locallyRepairableDrift(after.Reason) {
		// A missing remote prefix cannot be created from here. Report the
		// precise reason and let the bounded cycle decide whether the lab is
		// still converging or has to be escalated to an operator.
		return errors.New(semanticDriftReason(after, observation))
	}
	// A missing address or interface is a local fact this node owns, so it is
	// worth one bounded rewire of this device -- and of the neighbours whose
	// interfaces that rewire rebuilds. Rewiring re-renders the platform's own
	// files; anything a student wrote comes back from the snapshot store, and
	// never over a lab deployed at the reference.
	s.mu.Lock()
	mode, ungraded := s.modes[top.Name], s.ungraded[top.Name]
	s.mu.Unlock()
	if err := s.rewireWithPeers(ctx, rewireRequest{
		engine: eng, top: top, device: d,
		mode: render.Mode(mode), ungraded: ungraded,
	}); err != nil {
		return err
	}
	final := s.observeDevice(ctx, top.Name, d, false)
	s.rememberHealth(top.Name, d.ID, final)
	if final.Health == healthHealthy {
		return nil
	}
	return errors.New(semanticDriftReason(final, observation))
}

func semanticDriftReason(after, observation deviceObservation) string {
	if after.Reason != "" {
		return after.Reason
	}
	if observation.Reason != "" {
		return observation.Reason
	}
	return string(after.Health)
}

// restoreDeviceOverlayBindings puts back the VNI bindings and host-side ports
// of this device's cross-node links. It is idempotent, reports nothing for a
// device whose links are all local, and never removes a binding it did not
// expect: an extra one belongs to somebody else until ownership proves
// otherwise.
func (s *Server) restoreDeviceOverlayBindings(ctx context.Context, eng *deploy.Engine,
	top *model.Topology, d *model.Device,
) error {
	if !deviceHasCrossNodeLink(top, d, s.cfg.Node) {
		return nil
	}
	repair := s.overlayBindingRepair
	if repair == nil {
		repair = eng.ReconcileDeviceOverlayBindings
	}
	report, err := repair(ctx, top, d)
	if err != nil {
		return fmt.Errorf("restore cross-node bindings of %s: %w", d.ID, err)
	}
	if len(report.Failed) > 0 {
		return fmt.Errorf("restore cross-node bindings of %s: %s", d.ID,
			joinBindingFailures(report.Failed))
	}
	if len(report.Repaired) > 0 {
		s.metricRegistry().observeRepair("binding")
		s.recordEvent(top.Name, "", "reconcile", "", "overlay_binding_repair", "success",
			d.ID+": "+strings.Join(report.Repaired, ","))
		slog.Info("cross-node bindings restored", "lab", top.Name, "device", d.ID,
			"bindings", strings.Join(report.Repaired, ","))
	}
	return nil
}

func joinBindingFailures(failed map[string]string) string {
	out := make([]string, 0, len(failed))
	for binding, reason := range failed {
		out = append(out, binding+": "+reason)
	}
	sort.Strings(out)
	return strings.Join(out, "; ")
}

func deviceHasCrossNodeLink(top *model.Topology, d *model.Device, node string) bool {
	if top == nil || d == nil {
		return false
	}
	for _, link := range top.Links {
		if link == nil || !link.CrossNode() || link.VNI == 0 {
			continue
		}
		if link.A.Device.ID != d.ID && link.B.Device.ID != d.ID {
			continue
		}
		if link.A.Device.Node == node || link.B.Device.Node == node {
			return true
		}
	}
	return false
}

// locallyRepairableDrift names the semantic failures whose evidence and whose
// repair are both on this node. Everything else -- a withdrawn remote prefix,
// a session the far end has not brought up -- is deliberately excluded: a
// rewire cannot create it, and doing one anyway costs a live device its
// interfaces for nothing.
func locallyRepairableDrift(reason string) bool {
	for _, local := range []string{
		"is missing expected", // address or default route
		"has no usable OVS bridge",
		"is not tagged",
		"is missing VLAN",
	} {
		if strings.Contains(reason, local) {
			return true
		}
	}
	return false
}

// forceRewireDevice is the explicit operator path for a known broken link.
// It performs one bounded rewire with the same ownership/hold protections as
// automatic repair, and forces a stale active multiplex receive port to the
// deterministic pair assignment on both endpoint agents.
func (s *Server) forceRewireDevice(ctx context.Context, top *model.Topology, d *model.Device) error {
	if top == nil || d == nil {
		return errors.New("forced repair needs a topology device")
	}
	if who := s.heldBy(top.Name); who != "" {
		return fmt.Errorf("lab is held by %s", who)
	}
	if who := s.mutationLeaseHolder(top.Name); who != "" {
		return fmt.Errorf("lab has active fenced mutation by %s", who)
	}
	if reason := s.ordinaryMaintenanceSuppression(top.Name); reason != "" {
		return errors.New(reason)
	}
	repairCtx, cancel := context.WithTimeout(ctx, semanticRepairTimeout)
	defer cancel()
	opID, done, err := s.acquireOperation(top.Name, "forced-reconcile", cancel)
	if err != nil {
		return err
	}
	defer s.releaseOperation(top.Name, opID, done)
	eng := s.repairEngine(top)
	mode, ungraded := s.modeAndUngraded(top.Name)
	if err := s.rewireWithPeers(repairCtx, rewireRequest{
		engine: eng, top: top, device: d, mode: mode, ungraded: ungraded,
	}); err != nil {
		return err
	}
	after := s.observeDevice(repairCtx, top.Name, d, false)
	s.rememberHealth(top.Name, d.ID, after)
	if after.Health != healthHealthy {
		if isSemanticOnlyDrift(after.Reason) {
			// The physical repair is complete; BGP may need one hold timer to
			// reconverge. Keep the explicit degraded status but do not turn a
			// successful forced wire repair into an HTTP failure.
			return nil
		}
		reason := after.Reason
		if reason == "" {
			reason = string(after.Health)
		}
		return errors.New(reason)
	}
	s.repairSucceeded(top.Name, d.ID)
	return nil
}

// repairEngine is the explicit operator path: `node reconcile --force` may
// move a live receive socket, because converging two endpoints that disagree
// about it is impossible without doing so. The trunk's other bindings are
// preserved across that replacement by netx, so it is bounded to the port
// change the operator asked for.
func (s *Server) repairEngine(top *model.Topology) *deploy.Engine {
	eng := s.autoRepairEngine(top)
	eng.ForceOverlayReconcile = true
	return eng
}

// autoRepairEngine is what unattended repair is allowed to do.
//
// It deliberately does not force an overlay reconcile. One node pair shares
// one trunk, so forcing its receive socket deletes every VNI binding the pair
// carries and reinstalls only the link being repaired. An unattended audit did
// exactly that to a converged 84-AS lab: repairing one endpoint dropped a
// hundred and ten cross-node bindings, and the marks of every autonomous
// system behind them went with it five minutes after a clean deployment.
func (s *Server) autoRepairEngine(top *model.Topology) *deploy.Engine {
	s.mu.Lock()
	mode := s.modes[top.Name]
	ungraded := s.ungraded[top.Name]
	s.mu.Unlock()
	return &deploy.Engine{
		Runtime: s.rt, Node: s.cfg.Node, State: s.store,
		Limiter:               s.workLimiter(),
		Renderer:              renderer(top, render.Mode(mode), ungraded),
		WritesReference:       render.Mode(mode) == render.ModeSolve,
		UnderlayIP:            s.cfg.UnderlayIP,
		UnderlayDev:           s.cfg.UnderlayDev,
		PeerUnderlay:          s.peerUnderlay(top.Name),
		ModeKey:               rendererModeKey(render.Mode(mode), ungraded),
		ForceOverlayReconcile: false,
		ObservationRoot:       s.observationRoot,
	}
}

// reviveDevice moves a non-joinable desired container back to a state where
// wiring can be repaired. An absent container is recreated through the normal
// desired-state engine; exited, dead, and restart-loop states are actively
// restarted rather than being treated as healthy because an exec happened to
// be unavailable.
func (s *Server) reviveDevice(ctx context.Context, eng *deploy.Engine, top *model.Topology,
	d *model.Device, observation deviceObservation,
) error {
	if !observation.SpecMatches || observation.State == rt.StateAbsent {
		return s.recreateDesiredDevice(ctx, eng, top, d)
	}
	switch observation.State {
	case rt.StateRunning:
		return nil
	case rt.StatePaused:
		return s.workLimiter().Run(ctx, []limiter.Kind{limiter.Lifecycle}, func() error {
			return s.rt.Unpause(ctx, d.Container)
		})
	case rt.StateRestarting:
		// Stop breaks Docker's restart-policy loop before Start is asked to
		// create a fresh namespace. A plain Start on a restarting container is
		// often accepted but leaves the old loop in charge.
		if err := s.workLimiter().Run(ctx, []limiter.Kind{limiter.Lifecycle}, func() error {
			return s.rt.Stop(ctx, d.Container, 10*time.Second)
		}); err != nil {
			return err
		}
		fallthrough
	case rt.StateCreated, rt.StateExited, rt.StateDead:
		return s.workLimiter().Run(ctx, []limiter.Kind{limiter.Lifecycle}, func() error {
			return s.rt.Start(ctx, d.Container)
		})
	default:
		return fmt.Errorf("cannot revive container in unrecognised state %q", observation.State)
	}
}

// confirmDaemonRepair refreshes the stored health record after a control
// namespace repair. Without this, status could retain "bgpd (2)" long after a
// successful bounded repair had reduced it to one process.
func (s *Server) confirmDaemonRepair(ctx context.Context, top *model.Topology, d *model.Device) error {
	after := s.observeDevice(ctx, top.Name, d, false)
	s.rememberHealth(top.Name, d.ID, after)
	if after.Health == healthHealthy {
		return nil
	}
	reason := after.Reason
	if reason == "" {
		reason = string(after.Health)
	}
	return errors.New(reason)
}

func (s *Server) recreateDesiredDevice(ctx context.Context, eng *deploy.Engine, top *model.Topology,
	d *model.Device,
) error {
	p, err := eng.BuildContext(ctx, top)
	if err != nil {
		return err
	}
	p = p.Restrict(func(step *plan.Step) bool {
		return step.ID == "create:"+d.ID
	})
	report, err := p.Execute(ctx, plan.Options{
		Workers: 1, ContinueOnError: false,
	})
	if err != nil {
		return err
	}
	if report.Failed() {
		return report.Err()
	}
	return nil
}

func (s *Server) waitForJoinable(ctx context.Context, container string) error {
	var last string
	for attempt := 0; attempt < 25; attempt++ {
		observed, err := s.rt.Inspect(ctx, container)
		if err == nil && observed.State == rt.StateRunning {
			return nil
		}
		if err != nil {
			last = err.Error()
		} else {
			last = string(observed.State)
		}
		timer := time.NewTimer(100 * time.Millisecond)
		select {
		case <-ctx.Done():
			timer.Stop()
			return ctx.Err()
		case <-timer.C:
		}
	}
	if last == "" {
		last = "no runtime observation"
	}
	return fmt.Errorf("%s did not become joinable: %s", container, last)
}

// daemonsDown prefixes the reason a router is broken when the only thing wrong
// with it is that its routing processes are not running. The repair for that is
// to start them, not to rewire the device, so the two cases are told apart.
const daemonsDown = "these routing daemons are not running:"

const (
	controlDaemonRepairTimeout = 20 * time.Second
	controlDaemonProbeInterval = 200 * time.Millisecond
	semanticRepairTimeout      = 20 * time.Second
)

func (s *Server) probeExec(ctx context.Context, container string, cmd rt.ExecCmd) (rt.ExecResult, error) {
	var result rt.ExecResult
	err := s.workLimiter().Run(ctx, []limiter.Kind{limiter.ExecProbe}, func() error {
		var execErr error
		result, execErr = s.rt.Exec(ctx, container, cmd)
		return execErr
	})
	return result, err
}

// frrContainer selects the private privileged control sidecar for an FRR
// router. The router shell remains the student-facing container; daemon
// probes/restarts must never mistake its intentionally empty PID namespace for
// a dead control plane.
func (s *Server) frrContainer(ctx context.Context, d *model.Device) string {
	if d == nil {
		return ""
	}
	if deploy.UsesFRRControl(d) {
		name := deploy.FRRControlContainer(d)
		if c, err := s.rt.Inspect(ctx, name); err == nil && c.State != rt.StateAbsent {
			return name
		}
	}
	return d.Container
}

func (s *Server) requiresFRRControl(d *model.Device) bool {
	if !deploy.UsesFRRControl(d) {
		return false
	}
	switch runtimeNameForReconcile(s.rt) {
	case "docker", "podman", "containerd":
		return true
	default:
		return false
	}
}

func (s *Server) primaryFRRDaemonCount(ctx context.Context, d *model.Device) (int, error) {
	if !s.requiresFRRControl(d) {
		return 0, nil
	}
	const processes = `watchfrr|zebra|bgpd|ospfd|ospf6d|isisd|ldpd|pimd|staticd|bfdd|ripd|ripngd|pathd|sharpd|mgmtd`
	script := `ps -eo args= | awk '$0 ~ /\/usr\/lib\/frr\/(` + processes +
		`)( |$)/ || $0 ~ /(^|[[:space:]])watchfrr( |$)/ {n++} END {print n+0}'`
	result, err := s.probeExec(ctx, d.Container, rt.ExecCmd{Cmd: []string{"sh", "-c", script}})
	if err != nil {
		return 0, err
	}
	if result.ExitCode != 0 {
		return 0, fmt.Errorf("primary FRR daemon probe exited %d", result.ExitCode)
	}
	count, err := strconv.Atoi(strings.TrimSpace(result.Stdout))
	if err != nil {
		return 0, fmt.Errorf("parse primary FRR daemon count: %w", err)
	}
	return count, nil
}

func (s *Server) stopPrimaryFRRDaemons(ctx context.Context, d *model.Device) error {
	if !s.requiresFRRControl(d) {
		return nil
	}
	const processes = `watchfrr|zebra|bgpd|ospfd|ospf6d|isisd|ldpd|pimd|staticd|bfdd|ripd|ripngd|pathd|sharpd|mgmtd`
	script := strings.Join([]string{
		`find_frr() { ps -eo pid=,args= | awk '$0 ~ /\/usr\/lib\/frr\/(` + processes + `)( |$)/ || $0 ~ /(^|[[:space:]])watchfrr( |$)/ {print $1}'; }`,
		`pids="$(find_frr)"`,
		`if [ -n "$pids" ]; then kill $pids 2>/dev/null || true; sleep 1; fi`,
		`pids="$(find_frr)"`,
		`if [ -n "$pids" ]; then kill -9 $pids 2>/dev/null || true; sleep 1; fi`,
		`test -z "$(find_frr)"`,
	}, "\n")
	result, err := s.probeExec(ctx, d.Container, rt.ExecCmd{Cmd: []string{"sh", "-c", script}})
	if err != nil {
		return err
	}
	if err := result.Err(); err != nil {
		return fmt.Errorf("primary FRR daemon cleanup failed: %w", err)
	}
	return nil
}

// missingDaemons names the routing processes a router should be running and is
// not, or "" when they are all there.
func (s *Server) missingDaemons(ctx context.Context, d *model.Device, as *model.AS) string {
	missing, _ := s.missingDaemonsResult(ctx, d, as)
	return missing
}

func (s *Server) missingDaemonsResult(ctx context.Context, d *model.Device, as *model.AS) (string, error) {
	if s.requiresFRRControl(d) {
		counts, err := s.controlDaemonCounts(ctx, d, as)
		if err != nil {
			return "", err
		}
		var missing []string
		for _, name := range render.EnabledDaemonsFor(as) {
			if counts[name] == 0 {
				missing = append(missing, name)
			}
		}
		return strings.Join(missing, " "), nil
	}
	script := "miss=''; for p in " + strings.Join(render.EnabledDaemonsFor(as), " ") +
		"; do pidof \"$p\" >/dev/null 2>&1 || miss=\"$miss $p\"; done; echo \"$miss\""
	r, err := s.probeExec(ctx, s.frrContainer(ctx, d), rt.ExecCmd{Cmd: []string{"sh", "-c", script}})
	if err != nil || r.ExitCode != 0 {
		if err != nil {
			return "", err
		}
		return "", fmt.Errorf("daemon probe exited %d", r.ExitCode)
	}
	return strings.TrimRight(strings.TrimLeft(r.Stdout, " "), " \n"), nil
}

// brokenBecause names the first thing a device is missing, or "" if it is well.
func (s *Server) brokenBecause(ctx context.Context, lab string, d *model.Device) string {
	observation := s.observeDevice(ctx, lab, d, true)
	if observation.Health != healthBroken {
		return ""
	}
	return observation.Reason
}

// observeDevice classifies the desired device as healthy, broken, unknown, or
// partially wired. Unknown is deliberately not healthy: an unreadable runtime
// or failed exec supplies no evidence that a container is usable, but it also
// does not justify destructive rewiring while the node itself may be busy.
func (s *Server) observeDevice(ctx context.Context, lab string, d *model.Device, advancePartial bool) deviceObservation {
	if d == nil {
		return deviceObservation{Health: healthUnknown, Reason: "device declaration is unavailable"}
	}
	want := map[string]bool{}
	for _, i := range d.Ifaces {
		if i.Link != nil || i.VLAN > 0 {
			want[i.Name] = true
		}
	}
	// A device without modelled wires is still required to have a readable,
	// running runtime state. It is otherwise handled below.
	c, err := s.rt.Inspect(ctx, d.Container)
	if err != nil {
		return deviceObservation{Health: healthUnknown, Reason: "runtime inspect unreadable: " + err.Error()}
	}
	wantSpec, specErr := s.finalSpecHash(lab, d)
	if specErr != nil {
		return deviceObservation{Health: healthUnknown, State: c.State,
			Reason: "desired runtime specification is unreadable: " + specErr.Error()}
	}
	specMatches := c.Label(deploy.LabelSpec) == wantSpec
	s.mu.Lock()
	_, hasCurrentTopology := s.current[lab]
	s.mu.Unlock()
	if !hasCurrentTopology && c.Label(deploy.LabelSpec) == "" {
		// Synthetic/offline repair callers have no persisted topology from
		// which to derive a final OCI request. Do not turn that diagnostic
		// fallback into a recreation loop; active agent labs take the strict
		// contract path below.
		specMatches = true
	}
	if hasCurrentTopology && runtimeNameForReconcile(s.rt) != "" {
		specMatches = specMatches && c.Label(deploy.LabelRuntimeContract) == deploy.RuntimeSpecContractVersion
	}
	switch c.State {
	case rt.StateAbsent:
		return deviceObservation{Health: healthBroken, State: c.State, SpecMatches: specMatches, Reason: "container is absent"}
	case rt.StateExited:
		return deviceObservation{Health: healthBroken, State: c.State, SpecMatches: specMatches, Reason: "container is exited"}
	case rt.StateDead:
		return deviceObservation{Health: healthBroken, State: c.State, SpecMatches: specMatches, Reason: "container is dead"}
	case rt.StateRestarting:
		return deviceObservation{Health: healthBroken, State: c.State, SpecMatches: specMatches, Reason: "container is restart-looping"}
	case rt.StateCreated:
		return deviceObservation{Health: healthBroken, State: c.State, SpecMatches: specMatches, Reason: "container has not started"}
	case rt.StatePaused:
		return deviceObservation{Health: healthBroken, State: c.State, SpecMatches: specMatches, Reason: "container is paused"}
	case rt.StateRunning:
		// Continue below.
	default:
		return deviceObservation{Health: healthUnknown, State: c.State, SpecMatches: specMatches,
			Reason: "runtime returned an unknown container state"}
	}
	switch strings.ToLower(strings.TrimSpace(c.Health)) {
	case "", "healthy", "none":
		// Images without a Docker healthcheck intentionally report empty.
	case "unhealthy":
		return deviceObservation{Health: healthBroken, State: c.State, SpecMatches: specMatches, Reason: "container healthcheck is unhealthy"}
	case "starting":
		return deviceObservation{Health: healthUnknown, State: c.State, SpecMatches: specMatches, Reason: "container healthcheck is still starting"}
	default:
		return deviceObservation{Health: healthUnknown, State: c.State, SpecMatches: specMatches, Reason: "container healthcheck is unreadable"}
	}
	if !specMatches {
		return deviceObservation{Health: healthBroken, State: c.State, SpecMatches: false,
			Reason: "container specification no longer matches desired state"}
	}
	if len(want) == 0 {
		return deviceObservation{Health: healthHealthy, State: c.State, SpecMatches: specMatches}
	}

	res, err := s.probeExec(ctx, d.Container, rt.ExecCmd{
		Cmd: []string{"sh", "-c", `ip -o link show 2>/dev/null | awk -F': ' '{print $2}' | cut -d@ -f1`}})
	if err != nil || res.ExitCode != 0 {
		if err != nil {
			return deviceObservation{Health: healthUnknown, State: c.State, SpecMatches: specMatches,
				Reason: "interface probe unreadable: " + err.Error()}
		}
		return deviceObservation{Health: healthUnknown, State: c.State, SpecMatches: specMatches,
			Reason: fmt.Sprintf("interface probe exited %d", res.ExitCode)}
	}
	have := map[string]bool{}
	for _, n := range strings.Fields(res.Stdout) {
		have[n] = true
	}
	// A device with none of its interfaces is unambiguously broken. A device
	// missing some of them is far more likely to be a deploy in progress, and
	// rewiring underneath one would be worse than waiting for the next tick.
	present := 0
	for n := range want {
		if have[n] {
			present++
		}
	}
	switch {
	case present == 0:
		return deviceObservation{Health: healthBroken, State: c.State, SpecMatches: specMatches, Reason: "it has none of its interfaces"}
	case present < len(want):
		// A device missing some of its interfaces is usually a deploy in
		// progress, and rewiring underneath one would be worse than waiting.
		// But it used to wait for ever: the state was recognised, named in a
		// comment, and then reported as healthy, so a device that lost one
		// cable of six stayed that way until somebody redeployed. Its
		// neighbours failed to reach through it, and the marks landed on them.
		//
		// So it is given time to be a deploy, and repaired if it is not. The
		// count is per device, and cleared as soon as the device is whole.
		count := s.partialCount(lab, d.ID, advancePartial)
		missing := make([]string, 0, len(want)-present)
		for n := range want {
			if !have[n] {
				missing = append(missing, n)
			}
		}
		sort.Strings(missing)
		reason := "it is missing " + strings.Join(missing, ", ")
		if count < partialWiringGrace {
			return deviceObservation{Health: healthPartial, State: c.State, SpecMatches: specMatches, Reason: reason}
		}
		return deviceObservation{Health: healthBroken, State: c.State, SpecMatches: specMatches, Reason: reason}
	}
	s.wholeAgain(lab, d.ID)

	// The interfaces are there. A router still needs its daemons: after a
	// restart the namespace is new and FRR is not running in it.
	//
	// Each daemon is asked for by name. This used to run `vtysh -c "show
	// version"`, which answers as long as *any* daemon is up -- so a router
	// with zebra alive and ospfd and bgpd dead was reported healthy and never
	// looked at again. Thirty-odd routers were found in exactly that state,
	// and the only symptom was students being marked down for neighbours that
	// had no routing process.
	// Daemon names are an FRR implementation detail. Other registered router
	// NOSes still receive runtime/wiring health, but must not be declared
	// broken merely because they do not run bgpd or ospfd binaries.
	if d.Kind == model.KindRouter && d.EffectiveNOS() == model.DefaultNOS {
		if s.requiresFRRControl(d) {
			control := deploy.FRRControlContainer(d)
			sidecar, err := s.rt.Inspect(ctx, control)
			if err != nil {
				return deviceObservation{Health: healthUnknown, State: c.State, SpecMatches: specMatches,
					Reason: "FRR control sidecar inspect unreadable: " + err.Error()}
			}
			if !sidecar.State.Joinable() {
				return deviceObservation{Health: healthBroken, State: c.State, SpecMatches: specMatches,
					Reason: "FRR control sidecar is absent or not running"}
			}
			// Before anything is asked of the sidecar. A restarted router gets
			// a new network namespace and its sidecar does not follow: the
			// daemons below then answer for a namespace holding a loopback and
			// no cables, and every one of those answers is "healthy".
			if observation, split := controlNamespaceObservation(
				s.proveControlNamespace(ctx, d), c, specMatches); split {
				return observation
			}
			if primary, err := s.primaryFRRDaemonCount(ctx, d); err != nil {
				return deviceObservation{Health: healthUnknown, State: c.State, SpecMatches: specMatches,
					Reason: "primary FRR daemon probe unreadable: " + err.Error()}
			} else if primary > 0 {
				return deviceObservation{Health: healthBroken, State: c.State, SpecMatches: specMatches,
					Reason: fmt.Sprintf("primary router container still runs %d FRR daemon(s)", primary)}
			}
		}
		as := s.asOf(lab, d)
		if missing, probeErr := s.missingDaemonsResult(ctx, d, as); probeErr != nil {
			return deviceObservation{Health: healthUnknown, State: c.State, SpecMatches: specMatches,
				Reason: "routing-daemon probe unreadable: " + probeErr.Error()}
		} else if missing != "" {
			return deviceObservation{Health: healthBroken, State: c.State, SpecMatches: specMatches, Reason: daemonsDown + missing}
		}
		if dup, probeErr := s.duplicateDaemonsResult(ctx, d, as); probeErr != nil {
			return deviceObservation{Health: healthUnknown, State: c.State, SpecMatches: specMatches,
				Reason: "routing-daemon duplicate probe unreadable: " + probeErr.Error()}
		} else if dup != "" {
			return deviceObservation{Health: healthBroken, State: c.State, SpecMatches: specMatches,
				Reason: daemonsDown + " duplicated: " + dup}
		}
	}
	if d.Kind == model.KindSwitch {
		if r, err := s.probeExec(ctx, d.Container, rt.ExecCmd{
			Cmd: []string{"sh", "-c", "ovs-vsctl list-br 2>/dev/null | grep -c ."}}); err != nil {
			return deviceObservation{Health: healthUnknown, State: c.State, SpecMatches: specMatches,
				Reason: "switch bridge probe unreadable: " + err.Error()}
		} else if r.ExitCode != 0 {
			return deviceObservation{Health: healthUnknown, State: c.State, SpecMatches: specMatches,
				Reason: fmt.Sprintf("switch bridge probe exited %d", r.ExitCode)}
		} else if strings.TrimSpace(r.Stdout) == "0" {
			return deviceObservation{Health: healthBroken, State: c.State, SpecMatches: specMatches, Reason: "it has no bridge"}
		}
	}
	if reason := s.semanticReason(ctx, lab, d); reason != "" {
		fullReason := "network semantics drifted: " + reason
		if !s.semanticDriftActionable(lab, fullReason) {
			// The runtime, interfaces, addresses, and daemons above are all
			// locally sound. Remote routes and sessions are allowed to form
			// after a commit without an agent repeatedly reloading healthy
			// routers and resetting the very convergence it is observing.
			return deviceObservation{Health: healthHealthy, State: c.State, SpecMatches: specMatches}
		}
		return deviceObservation{Health: healthBroken, State: c.State, SpecMatches: specMatches,
			Reason: fullReason}
	}
	return deviceObservation{Health: healthHealthy, State: c.State, SpecMatches: specMatches}
}

// peerUnderlay returns the VTEP addresses recorded for a lab.
func (s *Server) finalSpecHash(lab string, d *model.Device) (string, error) {
	// Lightweight unit runtimes often embed a nil Runtime and expose no
	// concrete backend name. They cannot materialize a real OCI create
	// request, so retain the legacy hash only for that test/offline shape.
	// Docker/Podman agents always take the final-spec path below.
	if s.rt == nil || runtimeNameForReconcile(s.rt) == "" {
		return deploy.SpecHash(d), nil
	}
	s.mu.Lock()
	top := s.current[lab]
	mode := s.modes[lab]
	ungraded := s.ungraded[lab]
	s.mu.Unlock()
	if top == nil {
		return deploy.SpecHash(d), nil
	}
	eng := &deploy.Engine{
		Runtime: s.rt, Node: s.cfg.Node, State: s.store,
		Renderer:        renderer(top, render.Mode(mode), ungraded),
		WritesReference: render.Mode(mode) == render.ModeSolve,
		UnderlayIP:      s.cfg.UnderlayIP,
		UnderlayDev:     s.cfg.UnderlayDev,
		PeerUnderlay:    s.peerUnderlay(top.Name),
		ObservationRoot: s.observationRoot,
	}
	return eng.FinalSpecHash(top, d)
}

func runtimeNameForReconcile(r rt.Runtime) (name string) {
	defer func() {
		if recover() != nil {
			name = ""
		}
	}()
	return r.Name()
}

func (s *Server) peerUnderlay(lab string) map[string]string {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.peers[lab]
}

// startDaemons brings FRR back up on a router whose processes have died.
//
// Safe on a student's router because FRR reads its configuration from the file
// it was given, so starting a dead daemon restores what was there rather than
// replacing it.
func (s *Server) startDaemons(ctx context.Context, lab string, d *model.Device) error {
	if s.requiresFRRControl(d) {
		controlCtx, cancel := context.WithTimeout(ctx, controlDaemonRepairTimeout)
		defer cancel()
		control := deploy.FRRControlContainer(d)
		sidecar, err := s.rt.Inspect(controlCtx, control)
		if err != nil {
			return fmt.Errorf("inspect FRR control sidecar: %w", err)
		}
		if !sidecar.State.Joinable() {
			return fmt.Errorf("FRR control sidecar %s is not running; refusing to start daemons in primary", control)
		}
		if err := s.stopPrimaryFRRDaemons(controlCtx, d); err != nil {
			return fmt.Errorf("stop legacy primary FRR daemons: %w", err)
		}
		if err := s.stopControlDaemonSet(controlCtx, d); err != nil {
			return err
		}
		result, err := s.probeExec(controlCtx, control, rt.ExecCmd{
			Cmd: []string{"sh", "-c", "/usr/lib/frr/frrinit.sh start >/dev/null 2>&1"},
		})
		if err != nil {
			return err
		}
		if err := result.Err(); err != nil {
			return fmt.Errorf("start FRR control daemons: %w", err)
		}
		as := s.asOf(lab, d)
		var last error
		for {
			if err := s.verifyControlDaemonSet(controlCtx, d, as); err == nil {
				return nil
			} else {
				last = err
			}
			timer := time.NewTimer(controlDaemonProbeInterval)
			select {
			case <-controlCtx.Done():
				timer.Stop()
				return controlCtx.Err()
			case <-timer.C:
			}
			if deadline, ok := controlCtx.Deadline(); ok && time.Until(deadline) <= controlDaemonProbeInterval {
				break
			}
		}
		return fmt.Errorf("FRR control daemon set did not converge: %w", last)
	}
	// Stopped properly before being started.
	//
	// This used to kill watchfrr, delete the pid files, and start. Deleting the
	// pid files is what made it wrong: the init script then has no idea the
	// daemons are already running, so it starts a second copy of every one of
	// them. Four zebras were found in one container that way, and the symptom
	// is not a crash -- it is a router whose FRR configuration is correct, whose
	// running-config shows the address, and whose kernel interface never gets
	// it, because the zebra that owns the netlink socket is not the one holding
	// the configuration. Six routers of one system were in that state and every
	// grading run marked their owner down for it.
	script := strings.Join([]string{
		// watchfrr outlives a plain stop and holds the pid lock.
		"for p in $(ps -ef | awk '/watchfrr/ && !/awk/ {print $1}'); do kill $p 2>/dev/null || true; done",
		"/usr/lib/frr/frrinit.sh stop >/dev/null 2>&1 || true",
		// Anything that survived the stop, by name, because starting on top of
		// a live daemon is the failure above.
		"for p in $(ps -ef | awk '/usr\\/lib\\/frr\\// && !/awk/ && !/frrinit/ {print $1}'); do kill $p 2>/dev/null || true; done",
		"sleep 1",
		"rm -f /var/run/frr/*.pid /var/run/frr/*.vty 2>/dev/null || true",
		"/usr/lib/frr/frrinit.sh start >/dev/null 2>&1 || true",
	}, "\n")
	if _, err := s.probeExec(ctx, s.frrContainer(ctx, d), rt.ExecCmd{Cmd: []string{"sh", "-c", script}}); err != nil {
		return err
	}
	// And given time to come up.
	//
	// frrinit.sh returns before the daemons have forked and written their pid
	// files, so asking immediately answered "still not running" for daemons
	// that were seconds from being up. The repair reported failure three times
	// and gave up on routers that had in fact recovered, while the logs said
	// they could not be started.
	as := s.asOf(lab, d)
	var missing string
	for i := 0; i < 20; i++ {
		missing = s.missingDaemons(ctx, d, as)
		if missing == "" {
			duplicate, err := s.duplicateDaemonsResult(ctx, d, as)
			if err != nil {
				return err
			}
			if duplicate == "" {
				return nil
			}
			return fmt.Errorf("FRR control sidecar has duplicate daemons: %s", duplicate)
		}
		select {
		case <-ctx.Done():
			return ctx.Err()
		case <-time.After(time.Second):
		}
	}
	return fmt.Errorf("still not running:%s", missing)
}

// duplicateDaemons names routing processes a router is running more than one
// copy of.
//
// Two zebras is not a redundant router, it is a broken one: they compete for
// the same netlink socket and the same interface state, and the loser's
// configuration is applied to nothing. It produces a device whose files and
// whose running-config are both correct and whose kernel is not, which is
// indistinguishable from a student mistake and was being marked as one.
func (s *Server) duplicateDaemons(ctx context.Context, d *model.Device, as *model.AS) string {
	dup, _ := s.duplicateDaemonsResult(ctx, d, as)
	return dup
}

func (s *Server) duplicateDaemonsResult(ctx context.Context, d *model.Device, as *model.AS) (string, error) {
	if s.requiresFRRControl(d) {
		counts, err := s.controlDaemonCounts(ctx, d, as)
		if err != nil {
			return "", err
		}
		var dup []string
		for _, name := range render.EnabledDaemonsFor(as) {
			if count := counts[name]; count > 1 {
				dup = append(dup, fmt.Sprintf("%s (%d)", name, count))
			}
		}
		return strings.Join(dup, " "), nil
	}
	var dup []string
	for _, name := range render.EnabledDaemonsFor(as) {
		// The daemon proper, which is the one started with -d.
		//
		// Matching the name alone counted ldpd's two privilege-separated
		// children -- "ldpd -L" and "ldpd -E", which every healthy router
		// with LDP has -- as two extra copies of ldpd. Every router in the
		// lab was then declared broken and restarted, for ever, and the
		// symptom was a class whose marks fell a little further every time
		// it was graded.
		script := "ps -ef | awk '/usr\\/lib\\/frr\\/" + name + " -d/ && !/awk/' | wc -l"
		r, err := s.probeExec(ctx, s.frrContainer(ctx, d), rt.ExecCmd{Cmd: []string{"sh", "-c", script}})
		if err != nil || r.ExitCode != 0 {
			if err != nil {
				return "", err
			}
			return "", fmt.Errorf("duplicate daemon probe exited %d", r.ExitCode)
		}
		n, err := strconv.Atoi(strings.TrimSpace(r.Stdout))
		if err != nil {
			return "", fmt.Errorf("parse duplicate daemon count: %w", err)
		}
		if n > 1 {
			dup = append(dup, fmt.Sprintf("%s (%d)", name, n))
		}
	}
	if len(dup) == 0 {
		return "", nil
	}
	sort.Strings(dup)
	return strings.Join(dup, " "), nil
}

// Failed repairs are retried with bounded exponential backoff. The old
// "three strikes forever" rule hid devices that became repairable later; a
// full audit or a lifecycle event now retries them when their next bounded
// window opens, and any healthy observation clears the history immediately.
const repairAttemptsBeforeGivingUp = 3

// semanticRepairCycles bounds distributed convergence.
//
// A drift whose other half lives on another node cannot be repaired from
// here, and repeating a local repair that has already been proven not to fix
// it is not convergence -- it is a device that stays broken while the node
// keeps reporting work in progress. After this many complete local repair
// cycles the device enters an explicit terminal state, is alerted, and is
// left alone until it is observed healthy or an operator intervenes.
const semanticRepairCycles = 3

const (
	repairBackoffBase = time.Second
	repairBackoffMax  = 5 * time.Minute
)

// repairKey identifies a device within its lab.
//
// Keying on the device alone was wrong in a way that only shows up at class
// scale: every private grading harness contains as3/ATL, and so does the class
// lab. Three failed repairs in an abandoned harness therefore switched off
// self-repair for the real device of the same name, in the lab a class is
// being taught in, and nothing said so.
func repairKey(lab, id string) string { return lab + "|" + id }

func (s *Server) givingUpOn(lab, id string) bool {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.repairFails[repairKey(lab, id)] < repairAttemptsBeforeGivingUp {
		return false
	}
	until := s.repairNext[repairKey(lab, id)]
	return !until.IsZero() && s.nowTime().Before(until)
}

func (s *Server) repairFailed(lab, id, what string, err error) {
	k := repairKey(lab, id)
	s.mu.Lock()
	if s.repairFails == nil {
		s.repairFails = map[string]int{}
	}
	if s.repairNext == nil {
		s.repairNext = map[string]time.Time{}
	}
	s.repairFails[k]++
	n := s.repairFails[k]
	delay := repairDelay(n)
	s.repairNext[k] = s.nowTime().Add(delay)
	s.mu.Unlock()

	slog.Error(what, "lab", lab, "device", id, "err", err, "attempt", n)
	s.metricRegistry().observeRepair("failed")
	s.queueReconcileAfter(lab, id, delay)
	if n >= repairAttemptsBeforeGivingUp {
		slog.Warn("repair is entering bounded exponential backoff; a later event or audit will retry",
			"lab", lab, "device", id, "attempts", n, "backoff", delay)
	}
}

// deferSemanticRepair records one completed local repair cycle that did not
// converge, and decides whether the device gets another.
//
// Two outcomes are possible and no third one is: another bounded retry, or an
// explicit terminal state that stops retrying and says so. A device that
// retries for ever is indistinguishable from one that is being repaired, and
// the whole failure this bounds looked exactly like progress in the log.
func (s *Server) deferSemanticRepair(lab, id, reason string) {
	k := repairKey(lab, id)
	s.mu.Lock()
	if s.repairFails == nil {
		s.repairFails = map[string]int{}
	}
	if s.repairNext == nil {
		s.repairNext = map[string]time.Time{}
	}
	if s.semanticCycles == nil {
		s.semanticCycles = map[string]int{}
	}
	if s.repairTerminal == nil {
		s.repairTerminal = map[string]string{}
	}
	n := s.repairFails[k] + 1
	if n < repairAttemptsBeforeGivingUp {
		n = repairAttemptsBeforeGivingUp
	}
	s.repairFails[k] = n
	delay := repairDelay(n)
	s.repairNext[k] = s.nowTime().Add(delay)
	cycle := s.semanticCycles[k] + 1
	s.semanticCycles[k] = cycle
	terminal := cycle >= semanticRepairCycles
	if terminal {
		s.repairTerminal[k] = reason
	}
	s.mu.Unlock()

	if terminal {
		s.metricRegistry().observeRepair("terminal")
		slog.Error("distributed semantic repair did not converge within its bounded cycle; "+
			"the device is now in a terminal state and will not be retried automatically",
			"lab", lab, "device", id, "reason", reason, "cycles", cycle)
		s.recordEvent(lab, "", "reconcile", "", "semantic_repair_terminal", "error",
			id+": "+reason)
		return
	}
	s.metricRegistry().observeRepair("backoff")
	slog.Warn("semantic drift survived a local repair cycle; retrying within a bounded budget",
		"lab", lab, "device", id, "reason", reason,
		"cycle", cycle, "cycles", semanticRepairCycles, "backoff", delay)
	s.recordEvent(lab, "", "reconcile", "", "semantic_repair_deferred", "backoff", id+": "+reason)
	s.queueReconcileAfter(lab, id, delay)
}

// semanticRepairTerminalReason reports why a device's bounded distributed
// repair was abandoned, or "" while it is still converging.
func (s *Server) semanticRepairTerminalReason(lab, id string) string {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.repairTerminal[repairKey(lab, id)]
}

func isSemanticOnlyDrift(reason string) bool {
	return strings.HasPrefix(reason, "network semantics drifted:")
}

func forceSemanticRepair(ctx context.Context) bool {
	force, _ := ctx.Value(forceSemanticRepairKey{}).(bool)
	return force
}

func (s *Server) repairSucceeded(lab, id string) {
	s.mu.Lock()
	key := repairKey(lab, id)
	delete(s.repairFails, key)
	delete(s.repairNext, key)
	delete(s.semanticCycles, key)
	delete(s.repairTerminal, key)
	s.mu.Unlock()
}

// repairDelay is bounded exponential backoff that actually reaches its
// declared maximum. The shift used to be capped at eight, so the longest
// delay a device could ever wait was 256 seconds and repairBackoffMax was a
// constant nothing could read: the documented five-minute ceiling and the
// implemented one disagreed, which is precisely the kind of difference that
// is only discovered while reading a log that says the wrong thing.
func repairDelay(attempt int) time.Duration {
	if attempt < 1 {
		attempt = 1
	}
	delay := repairBackoffBase
	for i := 1; i < attempt; i++ {
		if delay >= repairBackoffMax {
			return repairBackoffMax
		}
		delay *= 2
	}
	if delay > repairBackoffMax {
		return repairBackoffMax
	}
	return delay
}

// labIsGone reports whether none of a lab's devices on this node still exist.
//
// "None at all" rather than "some", deliberately. A lab midway through being
// deployed, or one whose containers are stopped, must not be forgotten -- the
// record is what a restart needs in order to bring them back. Only a lab with
// nothing left of it on this node is one that has been removed.
func (s *Server) labIsGone(ctx context.Context, top *model.Topology) bool {
	mine := 0
	for _, d := range top.Devices {
		if d.Node != s.cfg.Node {
			continue
		}
		mine++
		c, err := s.rt.Inspect(ctx, d.Container)
		if err != nil {
			// Unreadable is not absent, and guessing here would throw away the
			// record of a live lab because the runtime was busy.
			return false
		}
		if c.State != rt.StateAbsent {
			return false
		}
	}
	return mine > 0
}

// forgetLab drops everything this node remembers about a lab.
func (s *Server) forgetLab(name string) {
	s.mu.Lock()
	delete(s.current, name)
	delete(s.modes, name)
	delete(s.ungraded, name)
	delete(s.peers, name)
	delete(s.exempt, name)
	delete(s.holds, name)
	// Each map is swept independently. They used to be nested inside the
	// repair-failure loop, so a lab with no recorded failures kept its health
	// and backoff entries for ever after it was removed.
	for _, records := range []map[string]string{s.repairTerminal} {
		for k := range records {
			if strings.HasPrefix(k, name+"|") {
				delete(records, k)
			}
		}
	}
	for _, counts := range []map[string]int{s.repairFails, s.semanticCycles, s.partial} {
		for k := range counts {
			if strings.HasPrefix(k, name+"|") {
				delete(counts, k)
			}
		}
	}
	for k := range s.repairNext {
		if strings.HasPrefix(k, name+"|") {
			delete(s.repairNext, k)
		}
	}
	for k := range s.health {
		if strings.HasPrefix(k, name+"|") {
			delete(s.health, k)
		}
	}
	store := s.store
	s.mu.Unlock()

	if store != nil {
		if err := store.ForgetTopology(name); err != nil {
			slog.Warn("removing the record of a lab that is gone", "lab", name, "err", err)
		}
	}
}

// partialWiringGrace is how many surveys a device may be missing some of its
// interfaces before it is treated as broken rather than as mid-deployment.
//
// Three surveys is three minutes, which is longer than any deploy takes to
// wire one device and far shorter than the "until somebody notices" that this
// replaced.
const partialWiringGrace = 3

func (s *Server) partialCount(lab, id string, advance bool) int {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.partial == nil {
		s.partial = map[string]int{}
	}
	k := repairKey(lab, id)
	if advance {
		s.partial[k]++
	}
	return s.partial[k]
}

// wholeAgain forgets that a device was ever partially wired.
func (s *Server) wholeAgain(lab, id string) {
	s.mu.Lock()
	delete(s.partial, repairKey(lab, id))
	s.mu.Unlock()
}

// asOf returns the autonomous system a device belongs to in a lab this node
// currently holds, or nil when the node has no record of it. It exists so that
// a per-AS decision -- which routing daemons should be running -- is made from
// the same declaration the renderer used.
func (s *Server) asOf(lab string, d *model.Device) *model.AS {
	if d == nil {
		return nil
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	top, ok := s.current[lab]
	if !ok || top == nil {
		return nil
	}
	return top.ASes[d.ASN]
}
