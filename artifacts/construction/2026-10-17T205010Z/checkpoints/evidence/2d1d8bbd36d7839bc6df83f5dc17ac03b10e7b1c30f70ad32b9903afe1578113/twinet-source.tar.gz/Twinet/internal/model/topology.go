package model

import (
	"crypto/sha256"
	"fmt"
	"sort"
	"strings"
)

// ConfigOwner says who is responsible for a piece of configuration. It is the
// runtime form of the Provisioning contract and the reason Twinet can both
// deliberately leave a network unfinished and still know the right answer.
type ConfigOwner string

const (
	// OwnerPlatform: Twinet renders and applies this configuration.
	OwnerPlatform ConfigOwner = "platform"
	// OwnerStudent: deliberately left unconfigured for the student to do.
	// Twinet still records the expected value for grading and for `twinet solve`.
	OwnerStudent ConfigOwner = "student"
)

// Topology is the fully expanded, resolved lab: every AS instantiated, every
// device named, every link endpoint concrete. Planning, placement, deployment
// and grading operate exclusively on this structure.
type Topology struct {
	Lab      *Lab
	Name     string
	Devices  map[string]*Device // keyed by Device.ID
	Links    []*Link
	ASes     map[int]*AS
	Services map[string]*Service

	// Hash is a content hash of the expanded topology, stamped onto every
	// container so drift between manifest and deployment is detectable.
	Hash string

	// Ephemeral marks a lab whose existence is owned by a running controller
	// rather than by a course. A grading harness is the only such lab today:
	// nobody's work lives in it, and it must not outlive the process that
	// asked for it. A teaching lab is never ephemeral, and the field is
	// deliberately not derivable from the manifest -- the caller that creates
	// a disposable lab says so explicitly.
	Ephemeral bool
	// EphemeralTTLSeconds is the lifetime a node grants this lab between
	// controller heartbeats. Zero asks the node for its own safe default.
	EphemeralTTLSeconds int
}

// AS is one expanded autonomous system.
type AS struct {
	ASN        int
	Role       ASRole
	Region     string
	Template   string
	OwnerGroup string
	Nickname   string
	Block      string // the AS's IPv4 /8, e.g. "12.0.0.0/8"
	BlockV6    string
	Devices    []*Device
	Routers    []*Device // subset of Devices, in template order
	ExtPorts   map[string]*ExtPortBinding
	Labels     map[string]string
	Node       string // pinned node, empty means "let the placer decide"

	// InteriorKind records the declaration that produced this AS. Legacy
	// templates are explicit. The expanded graph remains ordinary routers and
	// links, while this metadata lets placement and rubric validation make
	// shape-aware decisions without reparsing the authored template.
	InteriorKind  InteriorKind
	Distributable bool
	// PlacementGroups are atomic scheduling units. Most ASes have one; a
	// declared distributable Clos has one spine group and one group per leaf
	// with its directly attached hosts.
	PlacementGroups []*PlacementGroup

	// MPLS and VRFs carry the advanced course's label-switching and
	// virtual-routing configuration through to the renderer and the grader,
	// so both work from the same declaration rather than from two.
	MPLS      MPLSSpec
	Multicast MulticastSpec
	VRFs      map[string]*VRFSpec

	// Provisioned is the compiled result of the template's provisioning
	// declaration: the configuration domains Twinet configures even though this
	// is a student AS. Empty means the students configure everything, which is
	// what a teaching lab usually wants and what every manifest used to get
	// whatever it declared.
	Provisioned map[string]bool
	// ProvisionedIfaces are the individual interfaces named by an `iface` rule,
	// keyed "device/iface". A rule that names one was previously skipped
	// outright, so a service attachment declared as provisioned was left for
	// the student to guess at.
	ProvisionedIfaces map[string]bool
}

// PlacementGroup is a set of devices that must stay on one node. It is kept
// on its AS because group IDs are meaningful only within the AS that owns
// them, even though their IDs are globally namespaced for placement records.
type PlacementGroup struct {
	ID      string
	ASN     int
	Class   string
	Devices []*Device
}

// SortedPlacementGroups returns scheduling groups in stable ID order.
func (a *AS) SortedPlacementGroups() []*PlacementGroup {
	out := append([]*PlacementGroup(nil), a.PlacementGroups...)
	sort.Slice(out, func(i, j int) bool { return out[i].ID < out[j].ID })
	return out
}

// VRFsSorted returns the VRF names in a stable order.
func (a *AS) VRFsSorted() []string {
	out := make([]string, 0, len(a.VRFs))
	for n := range a.VRFs {
		out = append(out, n)
	}
	sort.Strings(out)
	return out
}

// InCore reports whether a router was declared part of the BGP-free core.
func (a *AS) InCore(name string) bool {
	for _, c := range a.MPLS.Core {
		if c == name {
			return true
		}
	}
	return false
}

// ExtPortBinding resolves a named external port to a concrete router.
type ExtPortBinding struct {
	Name   string
	Router *Device
	// VRF names the virtual routing table this port's interface joins.
	VRF string
}

// Device is one container in the expanded topology.
type Device struct {
	// ID is the globally unique device identity, "as12/ATL" or "svc/dns".
	ID   string
	Name string // short name within the AS, e.g. "ATL"
	Kind DeviceKind
	ASN  int // 0 for lab-global services

	Image string
	// NOS is the explicitly selected router NOS. Empty means the compatibility
	// default (FRR), which keeps manifests authored before NOS declarations
	// byte-for-byte topology compatible.
	NOS string
	// ImageID is the digest the reference resolved to when the lab was
	// planned. It is part of a container's identity: a tag rebuilt in place is
	// different software under an unchanged name.
	ImageID string
	CPUs    float64
	Memory  string
	Pids    int64
	// Requests is the fully resolved scheduling reservation. CPUs, Memory,
	// and Pids above remain hard container limits.
	Requests     ResourceRequest
	Restart      string
	Env          map[string]string
	Sysctls      map[string]string
	Capabilities []string
	Binds        []string
	Privileged   bool
	Command      []string
	Labels       map[string]string
	Hardening    RuntimeHardening

	// RouterID is the stable per-AS router index used by the addressing plan.
	RouterID int
	// InteriorRole and InteriorRoleIndex identify a generated device's role
	// within its AS. They are addressing and placement inputs, not a separate
	// runtime device kind.
	InteriorRole      InteriorRole
	InteriorRoleIndex int
	// PlacementGroup is the globally unique ID of the atomic group this
	// device belongs to. Empty retains ordinary AS-granular placement.
	PlacementGroup string
	// Node is the cluster node this device is placed on. Filled by the placer.
	Node string
	// Ifaces are the device's interfaces, in deterministic order.
	Ifaces []*Iface
	// Services names the services attached to this device.
	Services []string
	// ServiceKind is the declared kind of a service container, e.g.
	// "builtin.rpki".
	//
	// The renderer used to decide what daemon to start by looking for a
	// substring in the device's name, so a manifest that declared
	// `validator: {kind: builtin.rpki}` produced a container that validated
	// nothing and reported no error, while one that declared
	// `dns_probe: {kind: container}` had a resolver started inside it. What a
	// service is is declared; it does not have to be guessed.
	ServiceKind string
	// ServiceName, ServiceReplica, and ServiceIdentity describe a replica of
	// an auxiliary service. They stay empty for every legacy singleton so
	// existing container identities remain byte-for-byte compatible.
	ServiceName     string
	ServiceReplica  string
	ServiceIdentity string
	// P4 is present only on KindP4 devices. It is the compiled-program ABI
	// used by the renderer and fault engine; it never relies on a device name
	// or an undocumented BMv2 default.
	P4 *P4Runtime
	// OpenFlow is present only on KindController devices. Switches point back
	// to their controller through OpenFlowController.
	OpenFlow *OpenFlowRuntime
	// OpenFlowController is the ID of the controller that owns this OVS
	// switch. Empty deliberately means standalone OVS, the legacy behaviour.
	OpenFlowController string
	// L2Gateway is the L2 domain this router is gateway for, if any.
	L2Gateway string
	// VLANs is populated for switches: the set of VLAN ids in their domain.
	VLANs []int
	// L2Domain is the domain a switch or L2 host belongs to.
	L2Domain string
	// Owner identifies who may access this device (a student group, or staff).
	Owner string
	// Container is the runtime container name; derived, stable, unique.
	Container string
	// Hostname as seen inside the container.
	Hostname string
	// FRR is router-specific rendered configuration state.
	FRR *FRRConfig
}

// DefaultNOS is used for router devices whose manifest predates explicit NOS
// declarations. Keep the default in the model so every caller resolves the
// same legacy behaviour without importing a provider implementation.
const DefaultNOS = "frr"

// EffectiveNOS returns the selected router NOS, retaining FRR for legacy
// router declarations. Non-router devices return the empty string.
func (d *Device) EffectiveNOS() string {
	if d == nil || d.Kind != KindRouter {
		return ""
	}
	if d.NOS == "" {
		return DefaultNOS
	}
	return d.NOS
}

// IsRouter reports whether the device is a router.
func (d *Device) IsRouter() bool { return d.Kind == KindRouter }

// P4Runtime is the fully resolved BMv2 pipeline contract carried onto an
// expanded device. ProgramPath remains relative to the lab root so a topology
// is portable; ProgramDigest pins the bytes that are actually loaded.
type P4Runtime struct {
	ProgramPath       string
	ProgramDigest     string
	Language          string
	ThriftPort        int
	Table             string
	ForwardAction     string
	ThresholdRegister string
	RegisterValues    map[int]int
	Entries           []P4TableEntry
	ProbeSource       string
	ProbeDestination  string
}

// OpenFlowRuntime is the resolved controller endpoint contract.
type OpenFlowRuntime struct {
	Version  string
	Listen   string
	Port     int
	FailMode string
	Switches []string
}

// IfaceByName returns the named interface.
func (d *Device) IfaceByName(name string) (*Iface, bool) {
	for _, i := range d.Ifaces {
		if i.Name == name {
			return i, true
		}
	}
	return nil, false
}

// AddIface appends an interface, keeping the slice sorted by name for
// determinism.
func (d *Device) AddIface(i *Iface) {
	d.Ifaces = append(d.Ifaces, i)
	sort.SliceStable(d.Ifaces, func(a, b int) bool { return d.Ifaces[a].Name < d.Ifaces[b].Name })
}

// Iface is one network interface on a device.
type Iface struct {
	// Name is the in-container interface name, e.g. "port_HOU" or "ATL-L2.10".
	Name string
	// Device is the owning device.
	Device *Device
	// Link is the link this interface terminates, nil for pure sub-interfaces.
	Link *Link
	// MAC is the deterministic locally administered address.
	MAC string
	// Addr4 and Addr6 are the addresses from the plan. They are applied only
	// when Owner is OwnerPlatform; otherwise they are the *expected* answer.
	Addr4 string
	Addr6 string
	// Owner says whether Twinet configures this interface or the student does.
	Owner ConfigOwner
	// Prescribed says whether the assignment mandates this exact address.
	//
	// Some addresses are dictated ("the loopback of router Y is X.[150+Y].0.1")
	// and some are the student's to choose ("use the subnet X.200.0.0/23; you
	// are free to use any address in it"). Grading must not confuse the two: a
	// check that demanded the reference answer for a free choice would fail a
	// perfectly correct student, which is worse than not checking at all.
	Prescribed bool
	// Subnet is the prefix this interface's address must fall inside, used to
	// grade a free choice.
	Subnet string
	// VLAN is the access VLAN for switch ports and the tag for sub-interfaces.
	VLAN int
	// Trunk marks a switch port carrying tagged traffic for multiple VLANs.
	Trunk bool
	// Parent names the parent interface for VLAN sub-interfaces.
	Parent string
	// Role annotates what the interface is for, used by config rendering.
	Role IfaceRole
	// Peer is the interface at the other end, for point-to-point links.
	Peer *Iface
	// VRF names the virtual routing and forwarding instance this interface
	// belongs to, empty for the default table.
	//
	// A VRF is what makes two customers' identical private address space
	// coexist on one provider router: each has its own routing table, and the
	// interface facing a customer is enslaved to theirs. Without it the
	// advanced course's central exercise -- a BGP/MPLS L3VPN where two banks
	// both use 192.168.0.0/16 -- has no way to be expressed at all.
	VRF string
}

// IfaceRole classifies an interface for configuration rendering and grading.
type IfaceRole string

const (
	RoleLoopback   IfaceRole = "loopback"
	RoleIntraAS    IfaceRole = "intra-as"
	RoleInterAS    IfaceRole = "inter-as"
	RoleHostLink   IfaceRole = "host"
	RoleL2Uplink   IfaceRole = "l2-uplink"
	RoleL2Access   IfaceRole = "l2-access"
	RoleL2Trunk    IfaceRole = "l2-trunk"
	RoleL2SubIface IfaceRole = "l2-subiface"
	RoleService    IfaceRole = "service"
	RoleIXPLink    IfaceRole = "ixp"
	// RoleOpenFlowControl is a management cable. It must be configured with
	// an IP address but must never be added as an OVS data-plane bridge port.
	RoleOpenFlowControl IfaceRole = "openflow-control"
)

// InteriorRole classifies a generated device by its position in an AS shape.
type InteriorRole string

const (
	InteriorRoleExplicit InteriorRole = "explicit"
	InteriorRoleRing     InteriorRole = "ring"
	InteriorRoleHub      InteriorRole = "hub"
	InteriorRoleCore     InteriorRole = "core"
	InteriorRoleEdge     InteriorRole = "edge"
	InteriorRoleSpine    InteriorRole = "spine"
	InteriorRoleLeaf     InteriorRole = "leaf"
	InteriorRoleHost     InteriorRole = "host"
)

// LinkKind classifies how a link must be realised.
type LinkKind string

const (
	// LinkVeth is a point-to-point link between two devices.
	LinkVeth LinkKind = "veth"
	// LinkService is a point-to-point link to a lab-global service container.
	LinkService LinkKind = "service"
	// LinkFabric is a cable into a shared L2 fabric such as an IXP.
	LinkFabric LinkKind = "fabric"
)

// LinkClass distinguishes links emitted by a topology shape for placement
// locality reporting. Empty retains the legacy inferred classification.
type LinkClass string

const (
	LinkClassRing         LinkClass = "ring"
	LinkClassRingHub      LinkClass = "ring-hub"
	LinkClassCoreEdge     LinkClass = "core-edge"
	LinkClassSpineLeaf    LinkClass = "spine-leaf"
	LinkClassLeafHost     LinkClass = "leaf-host"
	LinkClassIntraAS      LinkClass = "intra-as"
	LinkClassInterAS      LinkClass = "inter-as"
	LinkClassService      LinkClass = "service"
	LinkClassHost         LinkClass = "host"
	LinkClassL2           LinkClass = "l2"
	LinkClassUnclassified LinkClass = "other"
)

// Link is a point-to-point layer-2 segment between exactly two interfaces.
// Twinet has no multi-access segments by design: switches are real devices, so
// every cable is a cable. This is what makes cross-node VXLAN trivial (a
// unicast tunnel with a static FDB and no learning or EVPN control plane).
type Link struct {
	// ID is a stable, order-independent identity used to derive the VNI, the
	// veth altname and the diffing key.
	ID string
	// Kind classifies the link.
	Kind LinkKind
	// A and B are the two endpoints.
	A *Iface
	B *Iface
	// Props are the resolved shaping properties.
	Props LinkProps
	// Subnet is the IPv4 prefix assigned to this link, if any.
	Subnet string
	// SubnetV6 is the IPv6 prefix, if any.
	SubnetV6 string
	// Rel is the business relationship for inter-AS links, from A's side.
	Rel Relationship
	// InterAS is true when A and B are in different ASes.
	InterAS bool
	// Segment names the shared broadcast domain this link belongs to, empty
	// for an ordinary point-to-point link.
	//
	// Twinet has no multi-access link type: a shared LAN is modelled as a real
	// switch with a cable to each participant, which is both what the hardware
	// actually is and what keeps cross-node wiring a simple two-ended tunnel.
	// Segment records the logical grouping so that addressing and validation
	// can treat those cables as one subnet.
	Segment string
	// VNI is the VXLAN network identifier used when the endpoints land on
	// different nodes. Deterministically derived from ID.
	VNI uint32
	// Owner says whether Twinet addresses this link or the student does.
	Owner ConfigOwner
	// Class identifies a generated link shape for placement reporting.
	Class LinkClass
	// AddressingField is the addressing expression used to number this link.
	// It lets validation describe generated role-addressed links accurately.
	AddressingField string
}

// LocalityClass returns the explicit generated class where present, otherwise
// derives a useful stable class for existing links.
func (l *Link) LocalityClass() LinkClass {
	if l == nil {
		return LinkClassUnclassified
	}
	if l.Class != "" {
		return l.Class
	}
	switch {
	case l.InterAS:
		return LinkClassInterAS
	case l.Kind == LinkService:
		return LinkClassService
	case l.A != nil && l.B != nil &&
		(l.A.Role == RoleHostLink || l.B.Role == RoleHostLink):
		return LinkClassHost
	case l.A != nil && l.B != nil &&
		(l.A.Role == RoleL2Access || l.A.Role == RoleL2Trunk || l.A.Role == RoleL2Uplink ||
			l.B.Role == RoleL2Access || l.B.Role == RoleL2Trunk || l.B.Role == RoleL2Uplink):
		return LinkClassL2
	case l.A != nil && l.B != nil &&
		(l.A.Role == RoleIntraAS || l.B.Role == RoleIntraAS):
		return LinkClassIntraAS
	default:
		return LinkClassUnclassified
	}
}

// PeerRelationship returns what the far side of this link is to the near side.
//
// Link.Rel is stated from A's point of view and says what A *is* to B, so
// deriving "what my neighbour is to me" needs two steps, and getting either
// wrong inverts the economics of the whole network. Doing it in one place is
// the point: the same two lines were written out separately in the renderer,
// in three grading checks and in the policy analyser, and one of them being
// backwards is not visible in any single file.
//
// It was backwards. A customer applied its customer-import policy to its
// provider, preferring the expensive path over the free one -- and because the
// grading checks derived the relationship the same way, the inverted answer was
// the one that scored full marks and a correct Gao-Rexford implementation would
// have been marked wrong.
func (l *Link) PeerRelationship(near *Iface) Relationship {
	if l == nil {
		return RelPeer
	}
	if near == l.A {
		// A is the Rel of B, so B is the inverse of that to A.
		return l.Rel.Inverse()
	}
	return l.Rel
}

// Endpoints returns the two interfaces in deterministic order.
func (l *Link) Endpoints() (*Iface, *Iface) { return l.A, l.B }

// CrossNode reports whether the link's endpoints are on different nodes.
func (l *Link) CrossNode() bool {
	if l.A == nil || l.B == nil || l.A.Device == nil || l.B.Device == nil {
		return false
	}
	return l.A.Device.Node != l.B.Device.Node
}

// Other returns the endpoint opposite to i.
func (l *Link) Other(i *Iface) *Iface {
	if l.A == i {
		return l.B
	}
	return l.A
}

// MakeLinkID builds the canonical, order-independent link identity.
func MakeLinkID(devA, ifA, devB, ifB string) string {
	a := devA + ":" + ifA
	b := devB + ":" + ifB
	if a > b {
		a, b = b, a
	}
	return a + "|" + b
}

// ServiceReplica is one deterministic instance of an auxiliary service.
//
// ID is a logical, stable identity (for example "dns/node-1" or
// "dns/shard-002"), while Device is the concrete container. Identity is the
// service-facing anycast or shard identity; it deliberately does not change
// when a replica is moved under an explicit rebalance or node-loss recovery.
type ServiceReplica struct {
	ID       string
	Index    int
	Shard    string
	Identity string
	// HomeNode is the deterministic preferred placement selected by expansion.
	// Node is the current recorded placement and may differ after an explicit
	// rebalance or node-loss recovery.
	HomeNode string
	Node     string
	Device   *Device
}

// Service is an expanded auxiliary service.
type Service struct {
	Name string
	Kind string
	// Device is retained as the canonical singleton (or first replica) for
	// backwards-compatible callers. New placement code uses Replicas.
	Device *Device
	// Replicas is empty for a legacy singleton. A declared scalable policy
	// fills it in stable ID order.
	Replicas []*ServiceReplica
	// Attachments maps each attached AS to the selected replica ID. It is
	// regenerated deterministically after placement, so a local replica is
	// selected whenever one exists.
	Attachments map[int]string
	Policy      ServiceReplicationPolicy
	Spec        *ServiceSpec
	PerAS       bool
	Attach      *ServiceAttach
	Listen      string
	Config      map[string]string
	Node        string
}

// SortedReplicas returns replicas in their stable logical identity order.
func (s *Service) SortedReplicas() []*ServiceReplica {
	if s == nil || len(s.Replicas) == 0 {
		return nil
	}
	out := append([]*ServiceReplica(nil), s.Replicas...)
	sort.Slice(out, func(i, j int) bool { return out[i].ID < out[j].ID })
	return out
}

// Replica returns the replica with the logical ID.
func (s *Service) Replica(id string) (*ServiceReplica, bool) {
	if s == nil {
		return nil, false
	}
	for _, r := range s.Replicas {
		if r != nil && r.ID == id {
			return r, true
		}
	}
	return nil, false
}

// ReplicaForAS returns the declared attachment target for one AS.
func (s *Service) ReplicaForAS(asn int) (*ServiceReplica, bool) {
	if s == nil {
		return nil, false
	}
	id := s.Attachments[asn]
	if id == "" {
		return nil, false
	}
	return s.Replica(id)
}

// ServiceByDevice returns the service and replica that own a device. It also
// understands pre-O6 singleton services whose Replicas slice is empty.
func (t *Topology) ServiceByDevice(device *Device) (*Service, *ServiceReplica, bool) {
	if t == nil || device == nil {
		return nil, nil, false
	}
	for _, name := range t.SortedServiceNames() {
		s := t.Services[name]
		if s == nil {
			continue
		}
		for _, r := range s.Replicas {
			if r != nil && r.Device == device {
				return s, r, true
			}
		}
		if s.Device == device {
			return s, nil, true
		}
	}
	return nil, nil, false
}

// FRRConfig holds the rendered routing configuration for a router, split by
// owner so that `twinet deploy` applies only the platform's part while
// `twinet solve` can additionally apply the student's part.
type FRRConfig struct {
	// Platform is the configuration Twinet always applies.
	Platform string
	// Expected is the reference solution: what a correct student would add.
	Expected string
	// Daemons is the FRR daemons file contents.
	Daemons string
}

// SortedDevices returns all devices in deterministic ID order.
func (t *Topology) SortedDevices() []*Device {
	out := make([]*Device, 0, len(t.Devices))
	for _, d := range t.Devices {
		out = append(out, d)
	}
	sort.Slice(out, func(i, j int) bool { return out[i].ID < out[j].ID })
	return out
}

// SortedASNs returns AS numbers in ascending order.
func (t *Topology) SortedASNs() []int {
	out := make([]int, 0, len(t.ASes))
	for n := range t.ASes {
		out = append(out, n)
	}
	sort.Ints(out)
	return out
}

// SortedServiceNames returns service names in deterministic order.
func (t *Topology) SortedServiceNames() []string {
	out := make([]string, 0, len(t.Services))
	for n := range t.Services {
		out = append(out, n)
	}
	sort.Strings(out)
	return out
}

// DevicesOnNode returns the devices placed on the named node.
func (t *Topology) DevicesOnNode(node string) []*Device {
	var out []*Device
	for _, d := range t.SortedDevices() {
		if d.Node == node {
			out = append(out, d)
		}
	}
	return out
}

// LinksTouchingNode returns links with at least one endpoint on the node.
func (t *Topology) LinksTouchingNode(node string) []*Link {
	var out []*Link
	for _, l := range t.Links {
		if (l.A != nil && l.A.Device.Node == node) || (l.B != nil && l.B.Device.Node == node) {
			out = append(out, l)
		}
	}
	return out
}

// Device looks up a device by ID.
func (t *Topology) Device(id string) (*Device, bool) {
	d, ok := t.Devices[id]
	return d, ok
}

// DeviceInAS finds a device by AS number and short name.
func (t *Topology) DeviceInAS(asn int, name string) (*Device, bool) {
	return t.Device(DeviceID(asn, name))
}

// DeviceID builds the canonical device identity.
func DeviceID(asn int, name string) string {
	if asn == 0 {
		return "svc/" + name
	}
	return fmt.Sprintf("as%d/%s", asn, name)
}

// ContainerName builds the runtime container name for a device.
func ContainerName(lab string, asn int, name string) string {
	var value string
	if asn == 0 {
		value = fmt.Sprintf("twinet-%s-svc-%s", lab, strings.ToLower(name))
	} else {
		value = fmt.Sprintf("twinet-%s-as%d-%s", lab, asn, strings.ToLower(name))
	}
	// containerd limits IDs to 76 bytes. Router control sidecars append
	// "-frr", so primary names reserve those four bytes. The digest suffix
	// keeps names that differ only after the readable prefix distinct.
	const primaryLimit = 72
	if len(value) <= primaryLimit {
		return value
	}
	sum := sha256.Sum256([]byte(value))
	const suffixLength = 13 // '-' plus 12 hexadecimal characters.
	prefix := strings.TrimRight(value[:primaryLimit-suffixLength], "._-")
	return prefix + fmt.Sprintf("-%x", sum[:6])
}

// Stats summarises a topology for status output and capacity planning.
type Stats struct {
	ASes      int
	Devices   int
	Routers   int
	Hosts     int
	Switches  int
	Services  int
	Links     int
	InterAS   int
	CrossNode int
	PerNode   map[string]int
}

// Stats computes summary statistics.
func (t *Topology) Stats() Stats {
	s := Stats{PerNode: map[string]int{}}
	s.ASes = len(t.ASes)
	s.Services = len(t.Services)
	for _, d := range t.Devices {
		s.Devices++
		s.PerNode[d.Node]++
		switch d.Kind {
		case KindRouter:
			s.Routers++
		case KindHost:
			s.Hosts++
		case KindSwitch:
			s.Switches++
		}
	}
	for _, l := range t.Links {
		s.Links++
		if l.InterAS {
			s.InterAS++
		}
		if l.CrossNode() {
			s.CrossNode++
		}
	}
	return s
}
