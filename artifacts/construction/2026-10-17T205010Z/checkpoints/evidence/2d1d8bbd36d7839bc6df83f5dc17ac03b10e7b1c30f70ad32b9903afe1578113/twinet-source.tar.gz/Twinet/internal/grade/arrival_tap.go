package grade

import (
	"context"
	"fmt"
	"math/rand/v2"
	"strings"
	"sync"
	"time"
)

// What a machine's own counters can and cannot witness.
//
// A global counter -- the resets it sent, the datagrams it took delivery of for
// a closed port, the echo requests it answered -- rises for every packet of
// that kind the kernel handled, whoever sent it and wherever it came from. Read
// before and after a probe it looks like proof that the probe arrived, and it
// is not. The machine is the submission's to run programs on, and a loop
// connecting to 127.0.0.1 raises the same counter as fast as it likes: measured
// on a lab router, `nc -z 127.0.0.1 1` in a loop moved `OutRsts` thirty times in
// three seconds and `NoPorts` twenty-one times, while every connection from the
// other side of the network was being dropped and the question about whether
// the paths carry traffic scored full marks.
//
// Two things are different now, and the second is what settles it.
//
// The counters are read together with the loopback device's packet count, and a
// packet a machine sends to itself is counted there as well -- twice, in fact,
// since the request and the answer are both delivered over `lo`. Subtracting
// the one from the other leaves movement the machine cannot have generated on
// its own. That is a lower bound and deliberately so: it can fail to credit an
// arrival, but it cannot invent one.
//
// A submission has more machines than one, though, and a connection to a closed
// port from any of them raises the counter without touching the loopback. So
// the counter is no longer the witness where a better one can be had. The
// destination watches its own interfaces for the exact flow the grader is about
// to create -- on a port drawn at random for that one probe, which nothing else
// has reason to send to -- and tcpdump names the interface each frame arrived
// on. Traffic a machine sends to itself names itself: even a connection to the
// machine's own routable address is delivered over `lo` and is reported as
// such, so it is excluded rather than counted.
//
// The two are required together. The tap sees a frame reach the interface,
// which is what the questions about paths and tunnels and transit are asking;
// the counter says the kernel took delivery of it, which is what the questions
// about reachability are asking. A submission that satisfies one and not the
// other has not carried the traffic, and neither witness alone was enough.

// counterWitness is a kernel counter read together with the loopback device's
// packet count, taken at the same instant so the two can be subtracted.
type counterWitness struct {
	global int
	loopRx int
}

// offBoxDelta is how much of a counter's movement between two readings cannot
// be explained by traffic the machine sent to itself.
func offBoxDelta(before, after counterWitness) int {
	n := (after.global - before.global) - (after.loopRx - before.loopRx)
	if n < 0 {
		return 0
	}
	return n
}

// readCounter reads one named counter out of a machine's SNMP statistics
// together with its loopback packet count, in a single visit.
func readCounter(ctx context.Context, env *Env, device, file string,
	pick func(string) (int, bool)) (counterWitness, bool) {

	res, err := env.Probe(ctx, device, []string{"cat", file, "/proc/net/dev"})
	if err != nil || res.ExitCode != 0 {
		return counterWitness{}, false
	}
	n, ok := pick(res.Stdout)
	if !ok {
		return counterWitness{}, false
	}
	return counterWitness{global: n, loopRx: loopbackRx(res.Stdout)}, true
}

// tapSeconds bounds how long a capture can outlive the grader that started it.
// It is a leak guard and nothing more: the capture is stopped explicitly when
// it is read, so this only matters if the grading run is interrupted between
// the two.
//
// It used to be the window itself, at fifteen seconds, chosen to outlast the
// probes it watches for. That was a guess about how long several round trips
// to a machine on another node would take, and on a loaded cluster the guess
// was sometimes wrong: the capture had already exited when the last probe was
// sent, reported no frames, and the check called a working path filtered.
const tapSeconds = 180

// tapFrames bounds how many frames a capture records, so that nothing
// unbounded is written to a machine being graded. Reaching the limit ends the
// capture early, which now voids the witness rather than silencing it, so the
// number is set well above what the probes can produce.
const tapFrames = 64

// arrivalTap watches one machine's interfaces for the frames of a single flow.
type arrivalTap struct {
	device    string
	file      string
	direction string
	begun     bool
	cleaned   bool
}

// startArrivalTap begins watching a machine for frames addressed to a port,
// whatever protocol carries them, and returns once the capture is listening.
//
// The wait is not optional. A capture that is still starting when the probe
// goes past records nothing, and a working path would be reported broken; the
// loop watches for tcpdump's own announcement that it is listening rather than
// guessing at a delay.
//
// The capture also records the moment it stops, in a marker file. Whether it
// was still running when the probes went past is the difference between "no
// packet arrived" and "nobody was watching", and only one of those is evidence.
func startArrivalTap(ctx context.Context, env *Env, device, port string) *arrivalTap {
	return startArrivalTapN(ctx, env, device, port, tapFrames)
}

// startArrivalTapN is startArrivalTap with the frame limit named, for the
// callers that aim more than one flow at the same port. Reaching the limit
// stops the capture early and voids its witness, so a caller sending many
// probes has to raise it or lose the evidence it went to the trouble of
// creating.
func startArrivalTapN(ctx context.Context, env *Env, device, port string, frames int) *arrivalTap {
	return startDirectionalTapN(ctx, env, device, port, frames, "in")
}

// startDepartureTapN is the source-side counterpart to startArrivalTapN. It
// proves that a packet whose absence may become a verdict actually left a real
// interface rather than merely being handed to a sender command.
func startDepartureTapN(ctx context.Context, env *Env, device, port string, frames int) *arrivalTap {
	return startDirectionalTapN(ctx, env, device, port, frames, "out")
}

func startDirectionalTapN(ctx context.Context, env *Env, device, port string,
	frames int, direction string,
) *arrivalTap {
	t := &arrivalTap{
		device:    device,
		file:      fmt.Sprintf("/tmp/twinet-tap-%d-%d", rand.Uint32(), rand.Uint32()),
		direction: direction,
	}
	script := fmt.Sprintf(
		"command -v tcpdump >/dev/null 2>&1 || exit 3; "+
			"rm -f %[1]s %[1]s.err %[1]s.pid %[1]s.end; "+
			"( ( timeout %[3]d tcpdump -i any -n -l -Q %[5]s -c %[4]d 'dst port %[2]s' "+
			">%[1]s 2>%[1]s.err & echo $! >%[1]s.pid; wait; : >%[1]s.end ) "+
			">/dev/null 2>&1 & ); "+
			"n=0; while [ $n -lt 100 ]; do "+
			"grep -q 'listening on' %[1]s.err 2>/dev/null && exit 0; "+
			"n=$((n+1)); sleep 0.05; done; exit 4",
		t.file, port, tapSeconds, frames, direction)
	res, err := env.Probe(ctx, device, []string{"sh", "-c", script})
	t.begun = err == nil && res.ExitCode == 0
	if !t.begun {
		t.cleanup(ctx, env)
	}
	return t
}

// cleanup stops and removes a capture using a context that survives a
// cancelled grading check. It is the last-resort path for a failed start or
// read; successful reads stop and remove the capture themselves.
func (t *arrivalTap) cleanup(ctx context.Context, env *Env) {
	if t == nil || t.cleaned || env == nil {
		return
	}
	cleanupCtx, cancel := context.WithTimeout(context.WithoutCancel(ctx), 5*time.Second)
	defer cancel()
	res, err := env.Probe(cleanupCtx, t.device, []string{"sh", "-c",
		fmt.Sprintf("[ -f %[1]s.pid ] && kill -TERM \"$(cat %[1]s.pid)\" 2>/dev/null; "+
			"n=0; while [ $n -lt 40 ] && [ ! -f %[1]s.end ]; do n=$((n+1)); sleep 0.05; done; "+
			"rm -f %[1]s %[1]s.err %[1]s.pid %[1]s.end; exit 0", t.file)})
	t.cleaned = err == nil && res.ExitCode == 0
}

// tapCounts is how many frames of each kind arrived on a real interface.
type tapCounts struct {
	tcp int
	udp int
}

// seen reports the frames of the watched flow that arrived from off the
// machine, and whether the capture was running to be able to say so.
//
// A capture that could not be read, or that cannot name the interface a frame
// arrived on, reports nothing rather than nothing-arrived: the difference
// matters, because the second would fail a submission over a missing tool.
//
// The capture is stopped here rather than left to expire, so that the window
// it watched covers the probes by construction instead of by estimate. If it
// stopped on its own beforehand -- its own timeout, or its frame limit -- it
// was not watching for the whole of the flow and its silence proves nothing.
func (t *arrivalTap) seen(ctx context.Context, env *Env) (tapCounts, bool) {
	c, _, live := t.seenFlows(ctx, env)
	return c, live
}

// seenFlows is seen, and also which source ports the arriving frames came
// from. A caller that aims several flows at one port distinguishes them that
// way: the source port is the only thing that differs between them, and it is
// also what the kernel hashes to choose between equal-cost next hops, so it
// names both the flow and the path it was steered onto.
func (t *arrivalTap) seenFlows(ctx context.Context, env *Env) (tapCounts, map[string]int, bool) {
	if t == nil || !t.begun {
		return tapCounts{}, nil, false
	}
	res, err := env.Probe(ctx, t.device, []string{"sh", "-c",
		fmt.Sprintf("early=0; [ -f %[1]s.end ] && early=1; "+
			"[ -f %[1]s.pid ] && kill -TERM \"$(cat %[1]s.pid)\" 2>/dev/null; "+
			"n=0; while [ $n -lt 40 ] && [ ! -f %[1]s.end ]; do n=$((n+1)); sleep 0.05; done; "+
			"echo \"EARLY=$early\"; cat %[1]s.err 2>/dev/null; echo '---'; "+
			"cat %[1]s 2>/dev/null; "+
			"rm -f %[1]s %[1]s.err %[1]s.pid %[1]s.end; exit 0", t.file)})
	if err != nil || res.ExitCode != 0 {
		t.cleanup(ctx, env)
		return tapCounts{}, nil, false
	}
	t.cleaned = true
	return parseTapFlowsDirection(res.Stdout, t.direction)
}

// parseTapOutput separates what tcpdump said about itself from what it
// captured, and reports nothing rather than nothing-arrived where the capture
// cannot be trusted to tell the difference.
func parseTapOutput(out string) (tapCounts, bool) {
	c, _, ok := parseTapFlows(out)
	return c, ok
}

// parseTapFlows is parseTapOutput, also grouping the arrivals by the source
// port they came from.
func parseTapFlows(out string) (tapCounts, map[string]int, bool) {
	return parseTapFlowsDirection(out, "in")
}

func parseTapFlowsDirection(out, direction string) (tapCounts, map[string]int, bool) {
	marker, rest, ok := strings.Cut(out, "\n")
	if !ok || !strings.HasPrefix(marker, "EARLY=") {
		return tapCounts{}, nil, false
	}
	// The capture had already stopped before it was asked, so the window it
	// watched does not cover the flow and it has nothing to testify to.
	if strings.TrimPrefix(marker, "EARLY=") != "0" {
		return tapCounts{}, nil, false
	}
	head, body, ok := strings.Cut(rest, "---\n")
	if !ok || !strings.Contains(head, "listening on") {
		return tapCounts{}, nil, false
	}
	// Without the cooked-v2 header there is no interface name on the line, and
	// a loopback frame is indistinguishable from an arrival. Better to have no
	// witness than a witness that cannot tell the two apart.
	if !strings.Contains(head, "LINUX_SLL2") {
		return tapCounts{}, nil, false
	}
	label := "In"
	if direction == "out" {
		label = "Out"
	}
	return countTapFramesDirection(body, label), tapSourcePortsDirection(body, label), true
}

// tapSourcePorts counts the arriving frames by the port they were sent from.
//
// tcpdump renders an address and port as one dotted field, so the port is
// what follows the last dot of the source field. A line whose source cannot
// be read that way is left out rather than guessed at: the caller counts a
// flow as lost when its port is absent, and a misparse would be an accusation
// against a submission that did nothing wrong.
func tapSourcePorts(body string) map[string]int {
	return tapSourcePortsDirection(body, "In")
}

func tapSourcePortsDirection(body, direction string) map[string]int {
	out := map[string]int{}
	for _, line := range strings.Split(body, "\n") {
		f := strings.Fields(line)
		if len(f) < 5 || f[2] != direction || f[1] == "lo" {
			continue
		}
		if !strings.Contains(line, "UDP,") && !strings.Contains(line, "Flags [") {
			continue
		}
		i := strings.LastIndex(f[4], ".")
		if i < 0 {
			continue
		}
		port := f[4][i+1:]
		if port == "" || strings.Trim(port, "0123456789") != "" {
			continue
		}
		out[port]++
	}
	return out
}

// countTapFrames reads tcpdump's `-i any` output, whose second field is the
// interface a frame arrived on and whose third says which way it went.
//
// Frames delivered over the loopback device are the machine talking to itself
// and are not arrivals.
func countTapFrames(body string) tapCounts {
	return countTapFramesDirection(body, "In")
}

func countTapFramesDirection(body, direction string) tapCounts {
	var c tapCounts
	for _, line := range strings.Split(body, "\n") {
		f := strings.Fields(line)
		if len(f) < 4 || f[2] != direction || f[1] == "lo" {
			continue
		}
		switch {
		case strings.Contains(line, "UDP,"):
			c.udp++
		case strings.Contains(line, "Flags ["):
			c.tcp++
		}
	}
	return c
}

// tapReading is what one capture saw, and whether it was running to see it.
type tapReading struct {
	counts tapCounts
	live   bool
}

// startTaps begins a capture on each of several machines at once, each watching
// for the port that machine's own probe will be aimed at.
func startTaps(ctx context.Context, env *Env, ports map[string]string) map[string]*arrivalTap {
	out := map[string]*arrivalTap{}
	var mu sync.Mutex
	var wg sync.WaitGroup
	sem := make(chan struct{}, 16)
	for device, port := range ports {
		wg.Add(1)
		go func(device, port string) {
			defer wg.Done()
			sem <- struct{}{}
			defer func() { <-sem }()
			t := startArrivalTap(ctx, env, device, port)
			mu.Lock()
			out[device] = t
			mu.Unlock()
		}(device, port)
	}
	wg.Wait()
	return out
}

// readTaps collects what every capture saw and clears them off the machines.
func readTaps(ctx context.Context, env *Env,
	taps map[string]*arrivalTap) map[string]tapReading {

	out := map[string]tapReading{}
	var mu sync.Mutex
	var wg sync.WaitGroup
	sem := make(chan struct{}, 16)
	for device, t := range taps {
		wg.Add(1)
		go func(device string, t *arrivalTap) {
			defer wg.Done()
			sem <- struct{}{}
			defer func() { <-sem }()
			counts, live := t.seen(ctx, env)
			mu.Lock()
			out[device] = tapReading{counts: counts, live: live}
			mu.Unlock()
		}(device, t)
	}
	wg.Wait()
	return out
}

// arrival is what one probe established about whether it got there.
type arrival struct {
	// frames matching the flow that reached a real interface.
	tapped int
	// tapLive is whether the capture was running to be able to say so.
	tapLive bool
	// counted is the counter movement the machine cannot have generated itself.
	counted int
	// counterOK is whether the counter could be read at all.
	counterOK bool
}

// arrived reports whether the probe is known to have got there.
//
// Where both witnesses are available both are required: the frame has to have
// reached an interface from off the machine, and the kernel has to have taken
// delivery of it. Where only one is available it decides alone, which is the
// weaker test the checks used to make everywhere.
func (a arrival) arrived() bool { return a.arrivedAtLeast(1) }

// arrivedAtLeast is arrived, for callers that sent several packets and want
// them all accounted for -- which is what an accusation should ask, so that one
// stray packet in the window is not a verdict.
func (a arrival) arrivedAtLeast(n int) bool {
	switch {
	case a.tapLive && a.counterOK:
		return a.tapped >= n && a.counted >= n
	case a.tapLive:
		return a.tapped >= n
	case a.counterOK:
		return a.counted >= n
	}
	return false
}

// attributable is whether the destination could be asked at all. Without it,
// arrived is not a negative finding, merely an unknown.
func (a arrival) attributable() bool { return a.tapLive || a.counterOK }

// why describes a failure to arrive in the terms of whichever witness saw it,
// so that a report says what was actually established.
func (a arrival) why() string {
	switch {
	case a.tapLive && a.tapped == 0:
		return "no packet of it reached any interface"
	case a.counterOK && a.counted == 0:
		return "it reached the interface but the kernel took no delivery of it"
	}
	return "it did not arrive"
}

// datagramAttempts is how many datagrams stand behind a claim that none arrived.
//
// UDP does not retransmit. One datagram lost to a full socket buffer, to a
// neighbour entry being resolved, or to a scheduler delay on a loaded node is
// indistinguishable from a network that discards the protocol -- and every
// check that sent one then told the student, in as many words, that something
// on the path was filtering by protocol. In a sixteen-submission class run of
// the reference solution it cost two correct submissions a mark, on a different
// pair of hosts each time.
//
// Several are sent and one arriving is enough, which is the tolerance the ping
// probes have had all along: they send two echo requests and ask for one.
const datagramAttempts = 3

// datagramProbe is a datagram to send, and what is known about where from.
//
// srcAddr may be empty. It is the sender's own address, used to pin every
// attempt to one source port, and where the caller does not know it the
// attempts are left to the kernel.
type datagramProbe struct {
	srcAddr string
	srcPort string
	dstAddr string
	port    string
	v6      bool
}

type datagramArrivalStatus uint8

const (
	datagramArrivalUnknown datagramArrivalStatus = iota
	datagramArrivalSeen
	datagramArrivalMissing
)

// probeDatagramArrival creates an attributable UDP witness independent of any
// earlier capture. A negative observation is not a verdict by itself; callers
// pass it through confirmedDatagramArrival.
func probeDatagramArrival(ctx context.Context, env *Env, from, to string,
	p datagramProbe, counter func(context.Context, *Env, string) (counterWitness, bool),
) (arrival, bool) {
	tap := startArrivalTap(ctx, env, to, p.port)
	before, okB := counter(ctx, env, to)
	sent := sendDatagrams(ctx, env, from, p)
	after, okA := counter(ctx, env, to)
	frames, live := tap.seen(ctx, env)
	return arrival{
		tapped: frames.udp, tapLive: live,
		counted: offBoxDelta(before, after), counterOK: okB && okA,
	}, sent
}

// confirmedDatagramArrival accepts one positive observation but requires two
// independent attributable negatives. Datagram probes are uniquely vulnerable
// to transient loss and capture scheduling; one silent round must not become a
// protocol-filter accusation.
func confirmedDatagramArrival(first arrival, sent bool,
	retry func() (arrival, bool),
) (arrival, datagramArrivalStatus) {
	if !sent || !first.attributable() {
		return first, datagramArrivalUnknown
	}
	if first.arrived() {
		return first, datagramArrivalSeen
	}
	second, sent := retry()
	if !sent || !second.attributable() {
		return second, datagramArrivalUnknown
	}
	if second.arrived() {
		return second, datagramArrivalSeen
	}
	return second, datagramArrivalMissing
}

// sendDatagrams sends the same datagram several times and reports whether the
// sender managed to send any of them.
//
// All of the attempts leave from one source port, not a fresh one each time,
// because a source port is not a path. Where equal-cost paths exist, a new port
// is hashed afresh and lands on whichever path happens to work, so a fault that
// discards one path clears itself on the retry -- which is finding 116, and is
// easier to repeat here than it looks. Pinned, the attempts all take the path
// the first one took, so a retry can rescue a dropped packet without rescuing a
// dropped path.
//
// A datagram that could not be sent is not a datagram that was lost. Binding a
// source port fails if the grader picked one already in use, and reading that
// as a datagram that did not arrive would blame a submission for the grader's
// own choice; such an attempt falls back to an unbound one so that the pair is
// still probed. An attempt is counted only when the sender said nothing at all,
// because netcat is silent on success and everything it does say -- a refused
// bind, a network with no route to the destination -- is a reason the datagram
// never left. The caller is told how many got away so it can stay silent rather
// than accuse on no evidence.
func sendDatagrams(ctx context.Context, env *Env, from string, p datagramProbe) bool {
	nc := "nc -u -w 1"
	if p.v6 {
		nc = "nc -6 -u -w 1"
	}
	send := func(bind bool) string {
		if bind {
			return fmt.Sprintf("echo twinet | %s -s %s -p $sport %s %s 2>&1 >/dev/null",
				nc, p.srcAddr, p.dstAddr, p.port)
		}
		return fmt.Sprintf("echo twinet | %s %s %s 2>&1 >/dev/null",
			nc, p.dstAddr, p.port)
	}
	var b strings.Builder
	b.WriteString("n=0; ")
	if p.srcAddr != "" {
		// One port for every attempt, drawn once. UDP has no lingering state
		// to stop it being bound again a moment later.
		srcPort := p.srcPort
		if srcPort == "" {
			srcPort = probePort()
		}
		fmt.Fprintf(&b, "sport=%s; ", srcPort)
	}
	for range datagramAttempts {
		if p.srcAddr != "" {
			fmt.Fprintf(&b, "e=$(%s); case \"$e\" in *bind*) e=$(%s);; esac; ",
				send(true), send(false))
		} else {
			fmt.Fprintf(&b, "e=$(%s); ", send(false))
		}
		b.WriteString("if [ -z \"$e\" ]; then n=$((n+1)); fi; ")
	}
	b.WriteString("echo sent=$n")
	res, err := env.Probe(ctx, from, []string{"sh", "-c", b.String()})
	if err != nil {
		return false
	}
	return !strings.Contains(res.Stdout, "sent=0")
}
