package cli

import (
	"context"

	"encoding/json"
	"fmt"
	"github.com/HongyuHe/twinet/internal/agent"
	"github.com/HongyuHe/twinet/internal/client"
	"github.com/HongyuHe/twinet/internal/deploy"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"syscall"
	"text/tabwriter"

	"github.com/spf13/cobra"

	"github.com/HongyuHe/twinet/internal/fault"
	"github.com/HongyuHe/twinet/internal/model"
	"github.com/HongyuHe/twinet/internal/netx"
	"github.com/HongyuHe/twinet/internal/runtime"
)

func newFaultCmd(opts *Options) *cobra.Command {
	cmd := &cobra.Command{
		Use:   "fault",
		Short: "Inject, verify and resolve network faults",
		Long: `Faults serve two purposes. In a course they are the scripted misconfiguration
an exercise is built around. In an evaluation they are the incident an AI agent
is asked to diagnose, following the taxonomy of the NIKA benchmark.

Every fault is reversible and every injection is verified: an incident that
failed to inject must never be presented to an agent as a puzzle.`,
	}
	cmd.AddCommand(
		newFaultListCmd(),
		newFaultInjectCmd(opts),
		newFaultResolveCmd(opts),
		newFaultStatusCmd(opts),
		newFaultVerifyCmd(opts),
	)
	return cmd
}

func newFaultListCmd() *cobra.Command {
	var asJSON bool
	cmd := &cobra.Command{
		Use:   "list",
		Short: "List the registered fault types",
		RunE: func(cmd *cobra.Command, _ []string) error {
			if asJSON {
				type out struct {
					Name         string               `json:"name"`
					Category     string               `json:"category"`
					Symptom      string               `json:"symptom"`
					Needs        []string             `json:"needs"`
					Requirements []fault.Requirement  `json:"requirements,omitempty"`
					Availability []fault.Availability `json:"availability"`
				}
				var list []out
				for _, f := range fault.All() {
					o := out{Name: f.Name, Category: string(f.Category), Symptom: f.Symptom,
						Requirements: append([]fault.Requirement(nil), f.Requires...),
						Availability: fault.AvailabilityFor(cmd.Context(), f, nil, fault.Target{})}
					for _, c := range f.Needs {
						o.Needs = append(o.Needs, string(c))
					}
					list = append(list, o)
				}
				enc := json.NewEncoder(cmd.OutOrStdout())
				enc.SetIndent("", "  ")
				return enc.Encode(list)
			}
			byCat := fault.ByCategory()
			cats := make([]string, 0, len(byCat))
			for c := range byCat {
				cats = append(cats, string(c))
			}
			sort.Strings(cats)
			w := tabwriter.NewWriter(cmd.OutOrStdout(), 0, 0, 2, ' ', 0)
			fmt.Fprintln(w, "FAULT\tCATEGORY\tNEEDS\tSUBSTRATE\tAVAILABILITY\tSYMPTOM AS REPORTED")
			for _, c := range cats {
				for _, f := range byCat[fault.Category(c)] {
					needs := make([]string, 0, len(f.Needs))
					for _, n := range f.Needs {
						needs = append(needs, string(n))
					}
					var substrate, availability string
					rows := fault.AvailabilityFor(cmd.Context(), f, nil, fault.Target{})
					for _, row := range rows {
						if row.Substrate != "" {
							substrate = string(row.Substrate)
						}
						if row.Mode != "" {
							if availability != "" {
								availability += ","
							}
							state := "unavailable"
							if row.Available {
								state = "available"
							}
							availability += string(row.Mode) + ":" + state
						}
					}
					if substrate == "" {
						substrate = "standard"
					}
					if availability == "" {
						availability = "native:available"
					}
					fmt.Fprintf(w, "%s\t%s\t%s\t%s\t%s\t%s\n", f.Name, c,
						strings.Join(needs, ","), substrate, availability, f.Symptom)
				}
			}
			if err := w.Flush(); err != nil {
				return err
			}
			fmt.Fprintf(cmd.OutOrStdout(), "\n%d fault types registered\n", len(fault.All()))
			return nil
		},
	}
	cmd.Flags().BoolVar(&asJSON, "json", false, "emit JSON")
	return cmd
}

// injectionsPath is where an injection record lives, so resolve can undo
// exactly what inject did after the process has exited.
func injectionsPath(top *model.Topology) string {
	return filepath.Join(top.Lab.Dir, ".twinet", "injections.json")
}

func loadInjections(top *model.Topology) ([]*fault.Injection, error) {
	raw, err := os.ReadFile(injectionsPath(top))
	if err != nil {
		if os.IsNotExist(err) {
			return nil, nil
		}
		return nil, err
	}
	var out []*fault.Injection
	return out, json.Unmarshal(raw, &out)
}

func saveInjections(top *model.Topology, in []*fault.Injection) error {
	p := injectionsPath(top)
	if err := os.MkdirAll(filepath.Dir(p), 0o700); err != nil {
		return err
	}
	// Narrowed every time, not only at creation: a lab directory made before
	// this rule existed would otherwise stay group-readable for the rest of its
	// life, and the agent account is in the invoking user's supplementary
	// groups often enough that "0750" and "unreadable" are not the same thing.
	sealLabState(top)
	raw, err := json.MarshalIndent(in, "", "  ")
	if err != nil {
		return err
	}
	// Written to a temporary file and renamed into place.
	//
	// This is the only record of what has been injected and how to undo it. A
	// partial write leaves live faults on the lab that nothing can name, and
	// the next episode runs on a network that is already broken in a way its
	// own ground truth does not mention. Rename is atomic on the same
	// filesystem, so a reader sees either the old file or the new one.
	//
	// Ground truth lives here, in the control plane, and is never written into
	// a container: an agent that could read the answer is not being measured.
	tmp, err := os.CreateTemp(filepath.Dir(p), ".injections-*")
	if err != nil {
		return err
	}
	defer func() { _ = os.Remove(tmp.Name()) }()
	if err := tmp.Chmod(0o600); err != nil {
		_ = tmp.Close()
		return err
	}
	if _, err := tmp.Write(raw); err != nil {
		_ = tmp.Close()
		return err
	}
	if err := tmp.Sync(); err != nil {
		_ = tmp.Close()
		return err
	}
	if err := tmp.Close(); err != nil {
		return err
	}
	if err := os.Rename(tmp.Name(), p); err != nil {
		return err
	}
	// Again, now the file exists: sealing before writing it left a root-owned
	// ledger inside a directory the operator owns, and their next ordinary
	// command in their own lab failed with "permission denied".
	sealLabState(top)
	return nil
}

// lockInjections serialises access to the record.
//
// Two injections at once would each read the file, add their own entry, and
// write back, so one of them would be forgotten -- left running on the lab with
// nothing able to name or undo it.
func lockInjections(top *model.Topology) (func(), error) {
	p := injectionsPath(top) + ".lock"
	if err := os.MkdirAll(filepath.Dir(p), 0o750); err != nil {
		return nil, err
	}
	f, err := os.OpenFile(p, os.O_CREATE|os.O_RDWR, 0o600)
	if err != nil {
		return nil, err
	}
	if err := syscall.Flock(int(f.Fd()), syscall.LOCK_EX); err != nil {
		_ = f.Close()
		return nil, fmt.Errorf("waiting for the injection record: %w", err)
	}
	return func() {
		_ = syscall.Flock(int(f.Fd()), syscall.LOCK_UN)
		_ = f.Close()
	}, nil
}

func newFaultInjectCmd(opts *Options) *cobra.Command {
	var (
		target   fault.Target
		params   []string
		token    string
		showTrue bool
	)
	cmd := &cobra.Command{
		Use:   "inject <fault>",
		Short: "Inject a fault and verify it took effect",
		Args:  cobra.ExactArgs(1),
		RunE: func(cmd *cobra.Command, args []string) error {
			top, err := loadAndPlace(opts)
			if err != nil {
				return err
			}
			env, err := faultEnv(cmd, top, token)
			if err != nil {
				return err
			}
			target.Params = parseKV(params)

			unlock, err := lockInjections(top)
			if err != nil {
				return err
			}
			defer unlock()

			// The record is read before anything is injected, and a read error
			// is fatal.
			//
			// It used to be read afterwards with the error discarded, so an
			// unreadable record became an empty one: every fault already on the
			// lab was forgotten, left running, and could never be resolved
			// because nothing knew it was there. The next episode then ran on a
			// network broken in a way its own ground truth did not mention.
			existing, err := loadInjections(top)
			if err != nil {
				return fmt.Errorf("the record of what is already injected could not be read (%w); "+
					"injecting now would leave whatever it holds running with nothing able to "+
					"name or undo it", err)
			}

			inj, err := fault.Inject(cmd.Context(), env, args[0], target)
			if err != nil {
				// A failed injection can still leave a live fault: when
				// verification fails and the rollback fails too, Inject
				// reports both and hands back what it created. Discarding it
				// left the device broken with nothing on disk saying so, and
				// its exemption from automatic repair still in place -- so
				// nothing would fix it and nothing would find it.
				if inj != nil {
					if serr := saveInjections(top, append(existing, inj)); serr != nil {
						return fmt.Errorf("%w; it is still live, and recording it failed too "+
							"(%v), so it must be undone by hand on %s", err, serr, target.DeviceID())
					}
					return fmt.Errorf("%w; it is still live and has been recorded, so "+
						"`twinet fault resolve --all` will try again", err)
				}
				return err
			}
			if err := saveInjections(top, append(existing, inj)); err != nil {
				// The fault is live and unrecorded. Undo it rather than leave
				// contamination nothing can find.
				if rerr := fault.Resolve(cmd.Context(), env, inj); rerr != nil {
					return fmt.Errorf("%s was injected but could not be recorded (%w), and undoing "+
						"it also failed (%v); the lab is contaminated and must be redeployed",
						args[0], err, rerr)
				}
				return fmt.Errorf("%s could not be recorded (%w), so it was undone rather than "+
					"left running with nothing able to name it", args[0], err)
			}

			fmt.Fprintf(cmd.OutOrStdout(), "injected %s on %s\n", inj.Fault, inj.Target.DeviceID())
			// Say what was checked and what was seen. Printing only Observed
			// showed an empty line whenever the symptom was an absence -- an
			// adjacency gone, no session established -- which is most of them,
			// so the one line meant to report the verdict was blank exactly
			// when the fault had worked.
			fmt.Fprintf(cmd.OutOrStdout(), "  verified: %s\n", describeEvidence(inj.Evidence))
			if f, ok := fault.Lookup(inj.Fault); ok {
				fmt.Fprintf(cmd.OutOrStdout(), "  reported symptom: %s\n", f.Symptom)
			}
			if showTrue {
				raw, _ := json.MarshalIndent(inj.Truth, "  ", "  ")
				fmt.Fprintf(cmd.OutOrStdout(), "  ground truth: %s\n", raw)
			} else {
				fmt.Fprintf(cmd.OutOrStdout(),
					"  ground truth withheld; pass --ground-truth to print it\n")
			}
			return nil
		},
	}
	cmd.Flags().IntVar(&target.AS, "as", 0, "target AS")
	cmd.Flags().StringVar(&target.Device, "device", "", "target device")
	cmd.Flags().StringVar(&target.Iface, "iface", "", "target interface")
	cmd.Flags().IntVar(&target.Peer, "peer", 0, "peer AS, for faults that need one")
	cmd.Flags().StringVar(&target.Prefix, "prefix", "", "prefix, for faults that need one")
	cmd.Flags().StringArrayVar(&params, "param", nil, "fault-specific argument, key=value")
	cmd.Flags().StringVar(&token, "token", "", "agent token for cluster labs")
	cmd.Flags().BoolVar(&showTrue, "ground-truth", false, "print the answer")
	return cmd
}

func newFaultResolveCmd(opts *Options) *cobra.Command {
	var (
		token string
		all   bool
	)
	cmd := &cobra.Command{
		Use:   "resolve [fault]",
		Short: "Undo an injected fault and confirm it is gone",
		RunE: func(cmd *cobra.Command, args []string) error {
			top, err := loadAndPlace(opts)
			if err != nil {
				return err
			}
			env, err := faultEnv(cmd, top, token)
			if err != nil {
				return err
			}

			// Held across the read, the resolving and the write.
			//
			// Injection takes this lock and resolution did not, so an
			// injection running concurrently was read, resolved from under
			// the other command, or overwritten by the record it wrote from
			// the copy it had read before this one started. Either way a fault
			// ends up live in the lab with nothing on disk saying so, which
			// makes it unresolvable except by hand.
			unlock, err := lockInjections(top)
			if err != nil {
				return err
			}
			defer unlock()

			injections, err := loadInjections(top)
			if err != nil {
				return err
			}
			if len(injections) == 0 {
				fmt.Fprintln(cmd.OutOrStdout(), "nothing is injected")
				return nil
			}

			// A bare fault name matches every injection of that kind, which is
			// what someone undoing a single fault means. An identifier matches
			// exactly one, which is what someone undoing one of several faults
			// of the same kind in a scenario means -- and before identifiers
			// existed there was no way to express it: resolving
			// `interface_down` on one router resolved it everywhere.
			if !all && len(args) > 0 {
				matched := false
				for _, inj := range injections {
					if inj.ID == args[0] || inj.Fault == args[0] {
						matched = true
						break
					}
				}
				if !matched {
					return fmt.Errorf("nothing injected matches %q; `twinet fault status` "+
						"lists what is live, with the identifier of each", args[0])
				}
			}

			var keep []*fault.Injection
			var resolved, failed int
			for _, inj := range injections {
				if !all && len(args) > 0 && inj.Fault != args[0] && inj.ID != args[0] {
					keep = append(keep, inj)
					continue
				}
				if err := fault.Resolve(cmd.Context(), env, inj); err != nil {
					fmt.Fprintf(cmd.ErrOrStderr(), "  %v\n", err)
					keep = append(keep, inj)
					failed++
					continue
				}
				fmt.Fprintf(cmd.OutOrStdout(), "resolved %s on %s (%s)\n",
					inj.Fault, inj.Target.DeviceID(), inj.ID)
				resolved++
			}
			if err := saveInjections(top, keep); err != nil {
				return err
			}
			if failed > 0 {
				return fmt.Errorf("%d of %d fault(s) could not be resolved; the lab is not back at baseline",
					failed, resolved+failed)
			}
			return nil
		},
	}
	cmd.Flags().BoolVar(&all, "all", false, "resolve every injected fault")
	cmd.Flags().StringVar(&token, "token", "", "agent token for cluster labs")
	return cmd
}

// newFaultVerifyCmd re-checks that what was injected is still in effect.
//
// Injection verifies once and rolls back if the fault did not take. But a lab
// runs for hours afterwards, and faults do not always stay: an interface comes
// back, a daemon is restarted, a container is replaced and takes the fault with
// it, a student repairs it by accident while looking for something else. An
// evaluation that assumes the fault is still there scores the agent's answer
// against a network that no longer has the problem -- and the episode looks
// entirely valid, so nothing questions the result.
func newFaultVerifyCmd(opts *Options) *cobra.Command {
	var token string
	cmd := &cobra.Command{
		Use:   "verify [fault]",
		Short: "Check that an injected fault is still in effect",
		Long: `Re-runs the same predicate injection used, against the lab as it is now.

An injected fault does not necessarily stay injected: a container may be
replaced, a daemon restarted, or the symptom repaired by accident. Anything
scored against ground truth should verify first.`,
		RunE: func(cmd *cobra.Command, args []string) error {
			top, err := loadAndPlace(opts)
			if err != nil {
				return err
			}
			env, err := faultEnv(cmd, top, token)
			if err != nil {
				return err
			}
			injections, err := loadInjections(top)
			if err != nil {
				return err
			}
			var want []*fault.Injection
			for _, inj := range injections {
				if len(args) == 0 || inj.Fault == args[0] {
					want = append(want, inj)
				}
			}
			if len(want) == 0 {
				if len(args) > 0 {
					return fmt.Errorf("%s is not injected", args[0])
				}
				fmt.Fprintln(cmd.OutOrStdout(), "nothing is injected")
				return nil
			}

			type row struct {
				ID       string         `json:"id"`
				Fault    string         `json:"fault"`
				Target   string         `json:"target"`
				Verified bool           `json:"verified"`
				Evidence fault.Evidence `json:"evidence"`
				Error    string         `json:"error,omitempty"`
			}
			var rows []row
			gone := 0
			for _, inj := range want {
				r := row{ID: inj.ID, Fault: inj.Fault, Target: inj.Target.DeviceID()}
				ev, err := fault.Verify(cmd.Context(), env, inj)
				switch {
				case err != nil:
					// A verification that could not run is not a fault that is
					// present. Reporting it as present is the failure mode this
					// command exists to catch.
					r.Error = err.Error()
					gone++
				case !ev.Verified:
					r.Evidence = ev
					gone++
				default:
					r.Verified, r.Evidence = true, ev
				}
				rows = append(rows, r)
			}
			if opts.JSON {
				enc := json.NewEncoder(cmd.OutOrStdout())
				enc.SetIndent("", "  ")
				if err := enc.Encode(rows); err != nil {
					return err
				}
			} else {
				w := tabwriter.NewWriter(cmd.OutOrStdout(), 0, 0, 2, ' ', 0)
				fmt.Fprintln(w, "FAULT\tTARGET\tSTILL IN EFFECT\tOBSERVED")
				for _, r := range rows {
					state := "yes"
					detail := r.Evidence.Observed
					if !r.Verified {
						state = "NO"
						if r.Error != "" {
							detail = r.Error
						}
					}
					fmt.Fprintf(w, "%s\t%s\t%s\t%s\n", r.Fault, r.Target, state, firstLineOf(detail))
				}
				if err := w.Flush(); err != nil {
					return err
				}
			}
			if gone > 0 {
				return fmt.Errorf("%d of %d injected fault(s) are no longer in effect; "+
					"anything scored against this lab's ground truth would be scored against "+
					"a problem that is not there", gone, len(rows))
			}
			return nil
		},
	}
	cmd.Flags().StringVar(&token, "token", "", "agent token for cluster labs")
	return cmd
}

// firstLineOf keeps a table one row per fault.
func firstLineOf(s string) string {
	if i := strings.IndexByte(s, '\n'); i >= 0 {
		return s[:i]
	}
	return s
}

func newFaultStatusCmd(opts *Options) *cobra.Command {
	var showTrue bool
	cmd := &cobra.Command{
		Use:   "status",
		Short: "Show what is currently injected",
		RunE: func(cmd *cobra.Command, _ []string) error {
			top, err := loadAndPlace(opts)
			if err != nil {
				return err
			}
			injections, err := loadInjections(top)
			if err != nil {
				return err
			}
			if len(injections) == 0 {
				fmt.Fprintln(cmd.OutOrStdout(), "nothing is injected")
				return nil
			}
			if opts.JSON {
				if !showTrue {
					for _, i := range injections {
						i.Truth = fault.GroundTruth{}
					}
				}
				enc := json.NewEncoder(cmd.OutOrStdout())
				enc.SetIndent("", "  ")
				return enc.Encode(injections)
			}
			w := tabwriter.NewWriter(cmd.OutOrStdout(), 0, 0, 2, ' ', 0)
			fmt.Fprintln(w, "FAULT\tTARGET\tINJECTED\tSYMPTOM")
			for _, i := range injections {
				sym := ""
				if f, ok := fault.Lookup(i.Fault); ok {
					sym = f.Symptom
				}
				fmt.Fprintf(w, "%s\t%s\t%s\t%s\n", i.Fault, i.Target.DeviceID(),
					i.InjectedAt.Format("15:04:05"), sym)
			}
			return w.Flush()
		},
	}
	cmd.Flags().BoolVar(&showTrue, "ground-truth", false, "include the answer")
	return cmd
}

// faultEnv builds the execution environment a fault runs in.
func faultEnv(cmd *cobra.Command, top *model.Topology, token string) (*fault.Env, error) {
	exec, err := execFunc(cmd.Context(), top, token)
	if err != nil {
		return nil, err
	}
	life, err := lifecycleFunc(top, token)
	if err != nil {
		return nil, err
	}
	reshape, err := reshapeFunc(top, token)
	if err != nil {
		return nil, err
	}
	nodeState, err := nodeStateFunc(top, token)
	if err != nil {
		return nil, err
	}
	exempt, err := exemptFunc(top, token)
	if err != nil {
		return nil, err
	}
	labelSpace, err := labelSpaceFunc(top, token)
	if err != nil {
		return nil, err
	}
	return &fault.Env{
		Topology: top, Exec: exec, Lifecycle: life,
		Reshape: reshape, NodeState: nodeState, Exempt: exempt, LabelSpace: labelSpace,
		FRRExec:    frrExecFunc(top, token, exec),
		Kubernetes: kubernetesBackendFromEnv(),
	}, nil
}

// frrExecFunc directs daemon lifecycle operations to the private FRR control
// sidecar. The router shell has only the capabilities students are allowed to
// have; vtysh still runs there through the shared vty socket.
func frrExecFunc(top *model.Topology, token string,
	regular func(context.Context, string, []string) (runtime.ExecResult, error),
) func(context.Context, string, []string) (runtime.ExecResult, error) {
	if !clustered(top) {
		rt, runtimeErr := localRuntime(top)
		return func(ctx context.Context, deviceID string, cmd []string) (runtime.ExecResult, error) {
			if runtimeErr != nil {
				return runtime.ExecResult{}, runtimeErr
			}
			d, ok := top.Device(deviceID)
			if !ok {
				return runtime.ExecResult{}, fmt.Errorf("no device %q", deviceID)
			}
			if !deploy.UsesFRRControl(d) {
				return regular(ctx, deviceID, cmd)
			}
			control := deploy.FRRControlContainer(d)
			if observed, err := rt.Inspect(ctx, control); err != nil || observed.State == runtime.StateAbsent {
				return regular(ctx, deviceID, cmd)
			}
			return rt.Exec(ctx, control, runtime.ExecCmd{Cmd: cmd})
		}
	}
	tok, err := tokenFor(token)
	if err != nil {
		// faultEnv already resolved token for normal exec. Preserve a closure
		// that reports the failure rather than panicking if configuration
		// changes between the two paths.
		return func(context.Context, string, []string) (runtime.ExecResult, error) {
			return runtime.ExecResult{}, err
		}
	}
	cl := client.NewCluster(top.Lab, tok)
	return func(ctx context.Context, deviceID string, cmd []string) (runtime.ExecResult, error) {
		d, ok := top.Device(deviceID)
		if !ok {
			return runtime.ExecResult{}, fmt.Errorf("no device %q", deviceID)
		}
		if !deploy.UsesFRRControl(d) {
			return regular(ctx, deviceID, cmd)
		}
		n, ok := cl.Node(d.Node)
		if !ok {
			return runtime.ExecResult{}, fmt.Errorf("device %s is on unknown node %q", deviceID, d.Node)
		}
		res, err := n.Exec(ctx, agent.ExecRequest{
			Container: deploy.FRRControlContainer(d), Cmd: cmd, Hold: currentHoldToken(), Grading: true,
		})
		return runtime.ExecResult{ExitCode: res.ExitCode, Stdout: res.Stdout, Stderr: res.Stderr}, err
	}
}

// labelSpaceFunc bridges the fault engine's typed request to either a local
// network namespace or the fenced node-agent API. Containers never receive
// direct write access to net.mpls.platform_labels.
func labelSpaceFunc(top *model.Topology, token string) (
	func(context.Context, string, fault.LabelSpaceRequest) (fault.LabelSpaceResult, error), error) {

	var localBackend runtime.Runtime
	if !clustered(top) {
		var err error
		localBackend, err = localRuntime(top)
		if err != nil {
			return nil, err
		}
	}
	local := func(ctx context.Context, deviceID string, req fault.LabelSpaceRequest) (fault.LabelSpaceResult, error) {
		d, ok := top.Device(deviceID)
		if !ok {
			return fault.LabelSpaceResult{}, fmt.Errorf("no device %q", deviceID)
		}
		ns, err := localBackend.NSPath(ctx, d.Container)
		if err != nil {
			return fault.LabelSpaceResult{}, err
		}
		switch req.Action {
		case "snapshot":
			s, err := netx.SnapshotMPLSLabelsInNS(ns)
			return fault.LabelSpaceResult{Limit: s.Limit, Allocated: s.Allocated, Labels: s.Labels, Exhausted: s.Exhausted, Detail: s.Detail}, err
		case "probe":
			s, err := netx.ProbeMPLSLabelExhaustionInNS(ns)
			return fault.LabelSpaceResult{Limit: s.Limit, Allocated: s.Allocated, Labels: s.Labels, Exhausted: s.Exhausted, Detail: s.Detail}, err
		case "exhaust":
			s, labels, err := netx.ExhaustMPLSLabelsInNS(ns, req.Limit)
			return fault.LabelSpaceResult{Limit: s.Limit, Allocated: s.Allocated, Labels: labels, Exhausted: s.Exhausted, Detail: s.Detail}, err
		case "restore":
			err := netx.RestoreMPLSLabelsInNS(ns, req.Limit, req.Labels)
			if err != nil {
				return fault.LabelSpaceResult{}, err
			}
			s, err := netx.SnapshotMPLSLabelsInNS(ns)
			return fault.LabelSpaceResult{Limit: s.Limit, Allocated: s.Allocated, Labels: s.Labels, Exhausted: s.Exhausted, Detail: s.Detail}, err
		default:
			return fault.LabelSpaceResult{}, fmt.Errorf("unknown MPLS label-space action %q", req.Action)
		}
	}
	if !clustered(top) {
		return local, nil
	}
	tok, err := tokenFor(token)
	if err != nil {
		return nil, err
	}
	cl := client.NewCluster(top.Lab, tok)
	return func(ctx context.Context, deviceID string, req fault.LabelSpaceRequest) (fault.LabelSpaceResult, error) {
		d, ok := top.Device(deviceID)
		if !ok {
			return fault.LabelSpaceResult{}, fmt.Errorf("no device %q", deviceID)
		}
		resp, err := cl.MPLSLabelSpace(ctx, top.Name, d.Node, agent.MPLSLabelSpaceRequest{
			Container: d.Container, Action: req.Action, Limit: req.Limit, Labels: req.Labels,
			Hold: currentHoldToken(),
		})
		return fault.LabelSpaceResult{
			Limit: resp.Limit, Allocated: resp.Allocated, Labels: resp.Labels,
			Exhausted: resp.Exhausted, Detail: resp.Detail,
		}, err
	}, nil
}

// exemptFunc returns a function that tells the node hosting a device to leave
// it alone while a fault is live.
//
// The record is kept on the node rather than in the container. A marker inside
// the device under test tells an agent being evaluated on root-cause analysis
// both that a fault was injected and, if it names the fault, what the answer
// is -- readable with `cat`, which makes the benchmark worthless.
func exemptFunc(top *model.Topology, token string) (
	func(context.Context, string, string, bool) error, error) {

	if !clustered(top) {
		// No agent, so no repair loop to exclude.
		return nil, nil
	}
	tok, err := tokenFor(token)
	if err != nil {
		return nil, err
	}
	cl := client.NewCluster(top.Lab, tok)
	return func(ctx context.Context, deviceID, injectionID string, on bool) error {
		d, ok := top.Device(deviceID)
		if !ok {
			return fmt.Errorf("no device %q", deviceID)
		}
		_, ok = cl.Node(d.Node)
		if !ok {
			return fmt.Errorf("device %s is on unknown node %q", deviceID, d.Node)
		}
		return cl.Exempt(ctx, d.Node, agent.ExemptRequest{
			Lab: top.Name, Device: deviceID, ID: injectionID, On: on,
			Hold: currentHoldToken(),
		})
	}, nil
}

func parseKV(in []string) map[string]string {
	if len(in) == 0 {
		return nil
	}
	out := map[string]string{}
	for _, kv := range in {
		if k, v, ok := strings.Cut(kv, "="); ok {
			out[k] = v
		}
	}
	return out
}

// describeEvidence renders a verification result as a sentence.
func describeEvidence(ev fault.Evidence) string {
	verdict := "no"
	if ev.Verified {
		verdict = "yes"
	}
	parts := []string{verdict}
	if ev.Expected != "" {
		parts = append(parts, "expected "+ev.Expected)
	}
	if ev.Observed != "" {
		parts = append(parts, "observed "+ev.Observed)
	}
	if ev.Detail != "" {
		parts = append(parts, ev.Detail)
	}
	return strings.Join(parts, "; ")
}
